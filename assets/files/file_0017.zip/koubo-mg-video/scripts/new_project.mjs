#!/usr/bin/env node
/**
 * 一键起工程：把模板复制到目标目录，接入口播底片，生成占位对齐。
 *
 * 用法：
 *   node scripts/new_project.mjs <目标目录>
 *   node scripts/new_project.mjs <目标目录> --video "D:/口播.mp4"
 *   node scripts/new_project.mjs <目标目录> --node-modules "E:/旧工程/node_modules"
 *
 * 说明：
 *   --node-modules 会建目录联接（junction）复用已有依赖，省一次 npm i。
 *   没有旧工程就自己 npm i（依赖约 300MB，第一次会慢）。
 */
import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TPL = path.resolve(HERE, '../assets/template');

const argv = process.argv.slice(2);
const target = argv[0];
if (!target || target.startsWith('--')) {
  console.error('用法: node scripts/new_project.mjs <目标目录> [--video 口播.mp4] [--node-modules 旧工程/node_modules]');
  process.exit(1);
}
const arg = (k) => {
  const i = argv.indexOf(k);
  return i >= 0 ? argv[i + 1] : undefined;
};
const video = arg('--video');
const nm = arg('--node-modules');

const DEST = path.resolve(target);
if (fs.existsSync(path.join(DEST, 'src', 'shots.ts'))) {
  console.error(`目标已存在工程：${DEST}\n换个目录，或先手动移除 src/shots.ts`);
  process.exit(1);
}

// ── 1. 复制模板（不带 out / analysis / node_modules） ──
fs.mkdirSync(DEST, { recursive: true });
fs.cpSync(TPL, DEST, {
  recursive: true,
  filter: (s) => !/node_modules|\\out\\|\/out\/|\\analysis\\|\/analysis\//.test(s),
});
console.log(`模板 -> ${DEST}`);

// ── 2. 依赖 ──
if (nm) {
  const link = path.join(DEST, 'node_modules');
  try {
    fs.symlinkSync(path.resolve(nm), link, 'junction');
    console.log(`node_modules 联接自 ${nm}`);
  } catch (e) {
    console.log(`联接失败（${e.message}），请自己 npm i`);
  }
} else if (!fs.existsSync(path.join(DEST, 'node_modules'))) {
  console.log('未提供 --node-modules，稍后需要在工程目录跑 npm i');
}

// ── 3. 口播底片 ──
if (video) {
  const pub = path.join(DEST, 'public');
  fs.mkdirSync(path.join(pub, 'audio'), { recursive: true });
  const dst = path.join(pub, 'voice.mp4');
  try {
    execFileSync('ffmpeg', ['-y', '-v', 'error', '-i', video, '-c:v', 'libx264', '-preset', 'fast',
      '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k', dst], { stdio: 'inherit' });
    console.log(`底片 -> public/voice.mp4`);
    execFileSync('ffmpeg', ['-y', '-v', 'error', '-i', video, '-vn', '-ac', '1', '-ar', '16000',
      '-c:a', 'aac', '-b:a', '128k', path.join(pub, 'audio', 'voice.m4a')], { stdio: 'inherit' });
    console.log('音轨 -> public/audio/voice.m4a');
  } catch (e) {
    console.log(`ffmpeg 处理失败：${e.message}\n请手动把底片放到 public/voice.mp4 并抽音轨`);
  }
}

// ── 4. 占位对齐（让工程能编译） ──
try {
  execFileSync('python', ['tools/align.py', '--stub'], { cwd: DEST, stdio: 'inherit' });
} catch (e) {
  console.log('占位对齐没跑成，稍后手动：python tools/align.py --stub');
}

console.log(`
下一步（都在 ${DEST}）：
  1. npm i                                   # 若没联接 node_modules
  2. python tools/probe.py                   # 量素材 + 抽帧给人脸标定
  3. 填 src/project.ts 的 face / brand / theme
  4. 填 src/shots.ts 的镜头表（台词词间用空格分隔）
  5. 写 src/scenes/*.tsx 并注册到 src/scenes/index.ts
  6. python tools/align.py                   # 真实语音对齐（关键）
  7. npx tsc --noEmit && python tools/qa.py --every 6
  8. npx remotion render src/index.ts Video out/video.mp4 --public-dir="$(pwd)/public"
`);

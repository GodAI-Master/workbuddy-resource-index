# 流水线详解

## 总览

```
关键词/文案 ──┐
              ├─→ ① 分镜剧本 ─→ ② 工程配置 ─→ ③ 镜头实现 ─→ ④ 对齐+声音 ─→ ⑤ 验收出片
口播底片 ─────┘                     ↑                              │
                              probe.py 标定人脸                align.py 定时间
```

阶段 ① 和 ② 可以并行；③ 是主要工作量；④ 决定成片"专业不专业"；⑤ 决定"能不能交付"。

---

## 阶段 ① 分镜剧本

**输入**：文案（或口播录音内容）+ 素材（截图/录屏）
**输出**：`src/shots.ts` 的 `SHOTS_DEF`

做法见 `script-and-shots.md`。硬要求：

- 每镜 3–6 秒，超过 7 秒必须拆
- 首镜必须在 3 秒内给出"这视频讲什么"，否则完播率崩
- 最后一镜要收口（回到一句话结论 / 四步清单 / 品牌点亮）
- 全片台词总量 ≈ 语音时长 × 4.2 字/秒。写多了必然"话说太快"，写少了会拖

**检查点**：把 `SHOTS_DEF` 的 `t1` 总和和 `probe.py` 报的真实时长对一下，误差应在 2% 内。

---

## 阶段 ② 工程配置

```bash
python tools/probe.py
```

看三件事：

1. **编码是不是 h264**。HEVC 10bit 在 Remotion 里 seek 慢、易黑帧，必须转：
   ```bash
   ffmpeg -i in.mp4 -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 160k public/voice.mp4
   ```
2. **铺三个抽帧里人脸的位置**。`analysis/face_check_mid.jpg` 打开，
   估脸中心像素坐标，填 `src/project.ts` 的 `face: { x, y }`。
   判据：填完之后气泡里"眼睛在圆的上 1/3 处"，不顶天不沉底。偏了就调 `y`（大 = 脸往上）。
3. **主题**。三种预设，按内容性格选：
   - `paper` 米白纸面 —— 教程、知识、工具、生活方式（最稳，九成场景适用）
   - `ink` 冷灰办公 —— B 端、SaaS、效率方法论
   - `night` 暗底霓虹 —— AI、科技、新品发布

**检查点**：`npx tsc --noEmit` 通过，`remotion still` 能出一帧（说明素材路径没 404）。

---

## 阶段 ③ 镜头实现

按幕分文件：`scenes/act1.tsx`、`act2.tsx`… 每幕 5–8 镜。
写完立刻注册到 `scenes/index.ts`，**没注册的镜头在成片里是空的**。

每镜的开发循环（不要写完 30 镜再一起看）：

```bash
npx remotion still src/index.ts Video out/qa/tmp.png --frame=<该镜中段帧> \
  --public-dir="$(pwd)/public"
```

看一眼 → 改 → 再看。一镜平均 2–3 轮。

**每镜必须自问的 4 个问题**：
1. 第一层是 `<StudioBG />` 吗？（MG/ASSET）
2. 有没有透出全屏真人？
3. 最长的那个元素会不会超出画外？
4. 说到第 1 个字的时候，画面动了吗？

---

## 阶段 ④ 对齐 + 声音

```bash
python tools/align.py
```

看诊断表：
- **语速列**：各句应在 ±20% 内浮动。某句 8.0 而其他 5.5 → 台词字数比实际说的多，改台词
- **dL/dR**：字幕相对初剪的偏移。标 `<<` 的句子超过 0.5s，少量正常
- **段数列**：某句只分到 1 个语音段而别的分到 5 个 → 这句可能被切在了别人说话的中间

对齐后**不要手改 `align.json`**（每次跑 align.py 会覆盖）。要调就调 `shots.ts` 的台词或 `align.py` 的参数（`LEAD`、`MINLEN`）。

音效：`SFX_DEF` 里 `word: k` 表示"第 k 个词起声时响"，`at: 1.2` 表示"镜头开始 1.2 秒后响"。
优先用 `word` —— 它自动跟着语音走，改台词不用重新调音效。

**检查点**：抽 3–4 个镜头看"字亮起来"和"画面动"是否同帧。差 3 帧以内算同拍。

---

## 阶段 ⑤ 验收出片

```bash
python tools/qa.py --every 5
```

终端会列每帧的亮度/对比/边缘值，异常的会被点名。然后**打开 `out/qa/grid.jpg` 人眼过一遍**。

修复顺序：穿帮（双人物/黑帧）> 需求未满足（字幕错拍/人物消失）> 质量瑕疵（对齐不齐/字太小）。

```bash
npx remotion render src/index.ts Video out/video.mp4 --public-dir="$(pwd)/public"
npx remotion render src/index.ts VideoNoBgm out/video-nobgm.mp4 --public-dir="$(pwd)/public"
ls -la out/*.mp4 && ffprobe -v error -show_entries format=duration -of csv=p=0 out/video.mp4
```

**必须核对时间戳和时长**。渲染 3459 帧约 8–12 分钟（4 核），别以为秒出就是成功了。

---

## 常见返工原因

| 现象 | 根因 | 修法 |
|---|---|---|
| 字幕always慢半拍 | 用了 stub 对齐或没跑 align.py | 跑 align.py，检查 `SUBS` 的 from 是否等于首字起声 |
| 石板一起落下 | 用了固定 delay 数组 | 改成 `wordFramesLocal(no)` |
| 开头 8 帧双人物 | StudioBG 有淡入 | `enter={0}` |
| 整帧空白 | 某个 zoom/translate 把内容推出画外 | 检查 `transformOrigin` 和起始 scale |
| 文字溢出卡片 | 字号写死没按字数算 | `fs = min(max, 宽度/字数×1.2)` |
| 素材加载 404 | public-dir 没传绝对路径 | 命令行加 `--public-dir="$(pwd)/public"` |

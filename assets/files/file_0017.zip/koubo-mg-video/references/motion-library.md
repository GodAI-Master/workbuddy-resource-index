# 动效元件与镜头配方

动效不是"加上去好看"，是**替观众指出该看哪里、以及这几件事之间是什么关系**。
每个动效都应该能回答："它帮观众理解了什么？"回答不了就删掉。

## 一、元件三层

### 版式件（kit.tsx）—— 搭画面骨架

| 元件 | 作用 | 关键参数 |
|---|---|---|
| `StudioBG` | 场景底：径向渐变 + 点阵 + 漂浮光斑 + 地面接影 | `dark` / `enter`（必须 0，否则透底片） |
| `GhostTitle` | 左上大标题 + 副标题（幽灵大字） | `size` 104 / `marker` 琥珀高亮块 |
| `WhiteCard` | 白卡容器 | `rot` 轻度旋转 ±1° |
| `Pill` | 圆角胶囊标签 | `active` 变品牌色 |
| `Ring` | 环形进度 | `progress` |
| `Stamp` | 圆形印章（盖章感） | `size` / `fontSize`（4 字要降字号） |
| `TopBrand` | 左上品牌区 | 由 `project.ts` 驱动 |
| `ProgressRail` | 顶部三站进度条 | `ACT_STATIONS` 驱动 |
| `springish` | 通用回弹插值 | `back` 1.5 |

### 强调件（fx.tsx）—— 指出"看这里"

| 元件 | 语义 | 用在 |
|---|---|---|
| `CircleMark` | 圈选（手绘圈） | "就是这个" |
| `Underline` | 下划线划过 | 关键词强调（比高亮块干净） |
| `ArrowCue` | 弧形箭头 | 因果指向（A → B） |
| `FocusFrame` | 矩形取景框 | 锁定一块区域 |
| `BurstTag` | 爆炸标签（带旋转） | 情绪强调（"完全浪费""0 → 1"） |
| `Sweep` | 扫光 | 读取/扫描/显影 |
| `Connector` | 连接线 | 两个元素的关联 |
| `Floaters` | 漂浮光斑 | 背景呼吸（StudioBG 已内置） |
| `PulseDot` | 脉冲点 | "正在进行" |
| `Sparkles` | 星芒 | 点亮/惊喜 |
| `Sticker` | 贴纸花字（带白底） | LIVE 镜头的伴随文字 |
| `BulletRow` | 要点条（主文 + 说明） | 填住画面空白 |
| `IconChip` | 图标徽章 | 角落装饰/标识 |
| `FlowLine` | 流动虚线 | 传输/流动 |
| `Bars` | 条形对比 | 数据量差异 |
| `CountUp` | 数字滚动 | 数量/时长强调 |
| `StatCard` | 统计卡（大数字 + 标签） | "8 层""3 条" |

### 招牌动效（moves.tsx）—— 一个镜头的主角

| 元件 | 视觉 | 适合表达 |
|---|---|---|
| `IrisCut` | 圆心虹膜切开，露出下一幕 | 章节切换、进入新主题（**必须与上一镜圆环同心**） |
| `FlipList` | 条目 3D 翻面揭示 | 并列结构（4 个维度 / 3 条共性） |
| `StairTrace` | 笔尖实时描线画阶梯 | 递进结构（8 层框架 / 步骤流程） |
| `RisoSlam` | 双色油墨套印 → 硬切套准 | 最强的一句结论（一屏只能出现一次） |
| `Spotlight` | 关灯 + 光池游走 + 锁定主角 | 展示一个"成果物"（报告/作品） |
| `ThemeSweep` | 斜向晨昏线扫过 | 情绪/主题转换（由亮转暗、由旧转新） |
| `Particles` | 粒子汇聚 / 迸发 | 归纳（gather）/ 高潮点亮（burst） |

## 二、7 个招牌的命门

做错这些细节，效果会从"高级"变成"廉价"。

### IrisCut 圆心匹配虹膜切
```tsx
<IrisCut cx={540} cy={1070} discText="8" startAt={0} />
```
- **圆心必须与上一镜的环严格同心**。差 20px 就假，观众能感觉到"切歪了"
- 开圈用 `Easing.bezier(0.62,0,0.32,1)`（ease-in 加速外扩），匀速外扩是"廉价"的主因
- 圆盘要在 34–48 帧"退成描边"，不要一直是个实心饼

### FlipList 互动翻面
```tsx
<FlipList items={...} times={wordFramesLocal('S08')} x={96} y={620} w={720} h={112} />
```
- 起始角 **88°，不是 180°**。180° 会看到卡片背面，很假
- 随角度做 `brightness` 衰减，模拟金属反光扫过
- `transformOrigin` 固定在左侧（或右侧），翻起来才像铰链

### StairTrace 描线阶梯
```tsx
<StairTrace steps={4} x={120} y={1080} stepW={210} stepH={-110}
  slabTexts={['对齐','卡点','落位','收口']} slabTimes={w} />
```
- 用 `pathLength={1}` + `strokeDashoffset` 描线，**并且必须自己算笔尖位置**（只画线不给笔＝没有"在写"的感觉）
- 台阶填充每级差 2 帧错峰，一起亮就是死的
- `stepH` 给负数就向上爬（更符合"往上走"的直觉）

### RisoSlam 孔版印刷冲击
```tsx
<RisoSlam text="全自动" size={300} regFrame={58} />
```
- `mixBlendMode:'multiply'` 才是油墨叠印；普通半透明是塑料感
- 抖动用**阻尼振荡** `cos(2πt/18)·e^(-t/60)`，不是随机抖
- 套准必须是**硬切**：那一帧偏移归零 + 1 帧 1.03 脉冲。渐渐归零就软了
- 一屏只能用一次，用两次就不"重"了

### Spotlight 聚光主角卡
```tsx
<Spotlight x={150} y={680} w={780} h={510} lockAt={26}>...</Spotlight>
```
- 暗场必须用 **SVG evenodd 挖孔**，`box-shadow` 挖不出圆角孔（会漏出卡的四角）
- 光池要"游走 2–3 站再锁定卡心"，直接锁＝没有叙事
- 卡要轻微抬升 + 呼吸（`lift`/`bob`），静态卡在暗场里像贴纸

### ThemeSweep 主题扫场
```tsx
<ThemeSweep from={C.bg} to={C.dark} startAt={8} dur={30} angle={-12} />
```
- `clip-path` 做硬边，边缘留一道高光扫过
- 斜度 -8° ~ -14° 最自然，0° 会像"擦窗"

### Particles 粒子
```tsx
<Particles count={24} mode="burst" cx={540} cy={1000} startAt={dur-40} />
```
- **必须用确定性伪随机**（`mulberry32`/固定 seed），否则每帧位置都变，闪成雪花

## 三、语义映射：要说什么，用什么

| 想表达 | 首选 | 备选 |
|---|---|---|
| "就是这个" | `CircleMark` | `FocusFrame` |
| "重点在这几个字" | `Underline` | `GhostTitle marker` |
| "A 导致 B" | `ArrowCue` | `Connector` + `PulseDot` |
| "这是错的" | `BurstTag`(red) + `Underline` 划掉 | 划线穿过文字 |
| "并列 N 项" | `FlipList` | 卡片扇形展开 |
| "递进 N 层" | `StairTrace` | 竖向堆叠 + 错峰浮入 |
| "流程串联" | `FlowLine` + 节点 | `Connector` 连环 |
| "批量处理" | 多卡扇形 + `Sweep` | `Bars` + `CountUp` |
| "归纳提炼" | `Particles` gather | 碎片向中心收拢 |
| "成果物" | `Spotlight` | 白卡抬升 + 轮廓光 |
| "盖章确认" | `Stamp` | `BurstTag`(green) |
| "最强结论" | `RisoSlam` | 冲击大字 + `Particles` burst |
| "主题/情绪转换" | `ThemeSweep` | 硬切 + 明暗反转 |
| "章节进入" | `IrisCut` | 缩圆转场 |
| "数字/规模" | `StatCard` + `CountUp` | `Bars` |

## 四、节奏规则

- **入场 8–16 帧**。20 帧以上的入场会显得拖；4 帧以内看不清
- **过冲只用一次**。每个元件都回弹 = 满屏弹簧，很廉价
- **每镜 1 个主动效 + 1–2 个辅助**。3 个以上观众不知道该看哪
- **主动效必须卡在语音上**（`wordFramesLocal`），辅助可以自由
- **镜头结尾留 6–10 帧静止**，让上一镜"落定"再切，不要每帧都在动

## 五、常见镜头配方

**双卡对比（旧解 vs 新解）**
两张白卡上下/左右错位浮入（`spring` damping 14，间隔 6 帧），中间 `Connector`，
旧卡上 `BurstTag`(red) + `Underline` 划掉，新卡 `Stamp`(green)。

**三卡扇形展开（并列）**
三张卡以中轴为原点旋转 -9°/0°/+9°，从 `translateY(80)` 落下，
每张卡内嵌一个 `Ring` 循环转动表示"进行中"。

**流程管线（串联）**
一条横向 `FlowLine` 虚线，3 个节点圆点依次点亮，
中间一个"包裹"（蓝图/文档图标）沿虚线从 A 移到 B，到达时 `drop` 音效。

**阶梯递进（八层/四步）**
`StairTrace` 画线 → 石板逐词落下 → 最后一块落时 `Particles` burst + `impact-big`。

**聚光成果（报告/作品）**
`Spotlight` 关灯 → 光池游走两站 → 锁卡 → 卡内条目逐条打勾 → `Stamp` 盖章。

**收尾清单（四步总结）**
竖排 4 行（①②③④ + 文字），逐行打勾（`CountUp`/`✓` 切换），
下方 logo 点亮 + 一句结论。

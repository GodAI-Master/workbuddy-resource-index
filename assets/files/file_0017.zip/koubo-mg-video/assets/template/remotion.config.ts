import { Config } from '@remotion/cli/config';
import path from 'path';

// public 目录必须显式给绝对路径：
// 工程目录若是中文路径、或用目录联接（junction）共享 node_modules，
// Remotion 自己推断 publicDir 会失败，报 404 拿不到素材。
Config.setPublicDir(path.resolve(__dirname, 'public'));
Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);

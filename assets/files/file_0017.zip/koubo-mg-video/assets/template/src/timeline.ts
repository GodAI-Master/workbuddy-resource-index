// ═══════════════════════════════════════════════════════
// 时间轴派生层 —— 不要手改这里
// 所有起止帧来自 src/align.json（tools/align.py 用真实语音强制对齐生成）：
//   VAD 找出全部语音段 → DP 把段落按"语速一致性"映射到每句台词
//   → 每个字拿到真实发音帧，静音处字幕不前进
//   → 镜头切点由该句首字起声反推（提前 0.14s 切过去）
// 三者（画面 / 字幕 / 口播）因此天然同拍
// ═══════════════════════════════════════════════════════
import alignData from './align.json';
import { SHOTS_DEF, ACT_STATIONS, WINDOWS, DEFAULT_WINDOW, SFX_DEF, BGM_VOLUME, ShotType, ShotDef, WinCfg } from './shots';

export const FPS = 30;
export const W = 1080;
export const H = 1920;

export const f = (sec: number) => Math.round(sec * FPS);

export type { ShotType, WinCfg };
export { ACT_STATIONS, BGM_VOLUME, WINDOWS };

export interface Shot extends ShotDef {
  from: number;
  to: number;
}

interface AlignShot {
  no: string;
  t0: number;
  t1: number;
  subFrom: number;
  subTo: number;
  nFrom: number;
  nTo: number;
  line: string;
  text: string;
  chars: { ch: string; s: number; e: number; br?: number }[];
}

const AL = alignData as unknown as AlignShot[];
const alByNo = (no: string) => AL.find((a) => a.no === no);

// 对齐结果缺这一镜时（新增镜头还没跑 align.py）退回初剪时间码，保证工程永远能渲染
export const SHOTS: Shot[] = SHOTS_DEF.map((s) => {
  const a = alByNo(s.no);
  return { ...s, from: a ? f(a.nFrom) : f(s.t0), to: a ? f(a.nTo) : f(s.t1) };
});

export const TOTAL = SHOTS.length ? SHOTS[SHOTS.length - 1].to : 1;

export const shotByNo = (no: string) => SHOTS.find((s) => s.no === no) ?? SHOTS[0];
export const shotDur = (s: Shot) => s.to - s.from;
export const shotAt = (frame: number) => SHOTS.find((s) => frame >= s.from && frame < s.to) ?? SHOTS[SHOTS.length - 1];

// ───────────────────────── 字幕系统 ─────────────────────────
export const stripPunct = (line: string) =>
  line.replace(/[，。、！？：；「」『』（）()《》——…·,.!?:;'"\s]/g, '');

export interface SubChar {
  ch: string;
  br?: boolean; // 词尾（折行点）
  start: number; // 帧
  end: number;
}
export interface SubLine {
  no: string;
  from: number;
  to: number;
  chars: SubChar[];
}

const subFromShots = (): SubLine[] =>
  SHOTS.map((s) => {
    const a = alByNo(s.no);
    if (a) {
      const chars = a.chars.map((c) => ({ ch: c.ch, br: !!c.br, start: f(c.s), end: f(c.e) }));
      return { no: s.no, from: chars[0].start, to: chars[chars.length - 1].end, chars };
    }
    // 无对齐数据：按镜头时长均分（仅用于快速预览，正式渲染前必须跑 align.py）
    const text = stripPunct(s.line);
    const n = Math.max(text.length, 1);
    const pad = Math.min(4, shotDur(s) * 0.06);
    const t0 = s.from + pad;
    const step = (s.to - pad * 0.4 - t0) / n;
    const chars: SubChar[] = text.split('').map((ch, i) => ({
      ch, start: Math.round(t0 + i * step), end: Math.round(t0 + (i + 1) * step),
    }));
    return { no: s.no, from: chars[0]?.start ?? s.from, to: chars[chars.length - 1]?.end ?? s.to, chars };
  });

export const SUBS: SubLine[] = subFromShots();
export const subByNo = (no: string) => SUBS.find((x) => x.no === no) ?? SUBS[0];

// ───────────────────────── 逐词起声帧 ─────────────────────────
// 镜头内的"第 k 个词"从哪一帧开始说 —— 一切逐词卡点（石板、列表、翻面）都从这里取
export const wordTimes = (no: string): { w: string; start: number; end: number; idx: number }[] => {
  const s = shotByNo(no);
  const a = alByNo(no);
  const words = s.line.split(/\s+/).map(stripPunct).filter(Boolean);
  if (!a) {
    const span = shotDur(s) / Math.max(words.length, 1);
    return words.map((w, i) => ({ w, start: s.from + Math.round(i * span), end: s.from + Math.round((i + 1) * span), idx: i }));
  }
  const res: { w: string; start: number; end: number; idx: number }[] = [];
  let idx = 0;
  for (const w of words) {
    const first = a.chars[Math.min(idx, a.chars.length - 1)];
    const last = a.chars[Math.min(idx + w.length - 1, a.chars.length - 1)];
    res.push({ w, start: f(first.s), end: f(last.e), idx });
    idx += w.length;
  }
  return res;
};

// ───────────────────────── 人像窗口 ─────────────────────────
export const personWinAt = (no: string): WinCfg => WINDOWS[no] ?? DEFAULT_WINDOW;
export const hasWindow = (no: string) => WINDOWS[no] !== undefined;

// ───────────────────────── SFX 钉帧 ─────────────────────────
export interface SfxCue {
  from: number;
  src: string; // public/audio/sfx/<src>.wav
  volume: number;
  dur?: number;
  note: string;
}

export const SFX: SfxCue[] = SFX_DEF.map((c) => {
  const s = shotByNo(c.no);
  const base = c.word !== undefined ? (wordTimes(c.no)[c.word]?.start ?? s.from) : s.from + f(c.at ?? 0);
  return { from: base, src: c.src, volume: c.vol, dur: c.dur ? f(c.dur) : undefined, note: c.note };
}).sort((a, b) => a.from - b.from);

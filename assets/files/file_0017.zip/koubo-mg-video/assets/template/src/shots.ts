// ═══════════════════════════════════════════════════════
// 镜头表 —— 全片唯一的人工编辑入口
//
// 规则：
// 1. t0/t1 是初剪时间码（按台词在口播里的大致位置估），跑完 tools/align.py
//    后会被真实语音起声覆盖，所以这里粗估即可（误差 1s 内都能救回来）
// 2. line 是这一句台词；词与词之间用【空格】分隔 —— 空格是逐词卡点的唯一依据，
//    说到第 3 个词时让第 3 块石板落下，靠的就是这个分词
// 3. 台词里不要写标点（逗号句号顿号分号冒号），会被 stripPunct 去掉；
//    需要断句就多切一个镜头，或用空格分词
// 4. type：LIVE = 全屏真人口播；MG = 纯动画（自带不透明背景）；
//    ASSET = 真实截图/录屏当主视觉
// ═══════════════════════════════════════════════════════

export type ShotType = 'LIVE' | 'MG' | 'ASSET';

export interface ShotDef {
  no: string;
  act: number;
  t0: number;
  t1: number;
  type: ShotType;
  line: string;
  title?: string;
  sub?: string;
}

const S = (
  no: string, act: number, t0: number, t1: number, type: ShotType,
  line: string, title?: string, sub?: string,
): ShotDef => ({ no, act, t0, t1, type, line, title, sub });

// ────────── 幕（顶部进度 rail 的三站） ──────────
export const ACT_STATIONS: { n: string; label: string; act: number }[] = [
  { n: '01', label: '铺垫', act: 1 },
  { n: '02', label: '演示', act: 3 },
  { n: '03', label: '串联', act: 5 },
];

// ────────── 镜头表（示例：6 镜 demo，跑通后替换成你的片子） ──────────
export const SHOTS_DEF: ShotDef[] = [
  S('S01', 1, 0.00, 3.60, 'LIVE', '这是一个口播视频自动加动画的演示'),
  S('S02', 2, 3.60, 7.40, 'MG', '画面会跟着你说话的节奏一个个落下来', '跟着语音走', '说到就出现'),
  S('S03', 3, 7.40, 11.20, 'ASSET', '真实的截图和录屏可以当主视觉 空白处补上动态内容'),
  S('S04', 3, 11.20, 15.00, 'MG', '字幕逐字高亮 当前这个字会亮起来', '逐字高亮', '开口才走字'),
  S('S05', 4, 15.00, 18.60, 'LIVE', '人物可以缩成右下角的圆形气泡陪你讲'),
  S('S06', 4, 18.60, 22.00, 'MG', '最后收口 全片节奏和口播一格不差', '一格不差'),
];

// ────────── 人物窗口（只在 MG / ASSET 生效；LIVE 自动全屏） ──────────
// circle = 圆形气泡（右下角最常见）；panel = 竖版面板（让出中部给内容时用）
// 位置切换一律在镜头开头 12 帧内一步到位，禁止连续漂移
export type WinCfg =
  | { shape: 'circle'; cx: number; cy: number; r: number }
  | { shape: 'panel'; side: 'left' | 'right'; cy: number; w: number; h: number };

const circle = (cx: number, cy: number, r: number): WinCfg => ({ shape: 'circle', cx, cy, r });

export const WINDOWS: Record<string, WinCfg> = {
  S02: circle(872, 1600, 142),
  S03: circle(872, 1600, 138),
  S04: circle(872, 1600, 142),
  S06: circle(860, 1580, 168),
};

export const DEFAULT_WINDOW: WinCfg = circle(872, 1600, 142);

// ────────── 动效音效钉帧表 ──────────
// at：相对镜头起点的秒数；word：改为钉在"第几个词的真实起声"（0 起算，优先于 at）
// vol 一律压低（0.08–0.20），动效声永远不能盖住口播
export interface SfxDef {
  no: string;
  at?: number;
  word?: number;
  src: string;
  vol: number;
  dur?: number;
  note: string;
}

export const SFX_DEF: SfxDef[] = [
  { no: 'S01', at: 0.3, src: 'pop', vol: 0.12, note: '标题弹入' },
  { no: 'S02', at: 0.2, src: 'swoosh', vol: 0.11, note: '卡片浮入' },
  { no: 'S02', word: 1, src: 'drop', vol: 0.13, note: '第一块落下（跟着"跟着"起声）' },
  { no: 'S02', word: 2, src: 'drop', vol: 0.13, note: '第二块' },
  { no: 'S02', word: 3, src: 'impact-big', vol: 0.18, note: '最后一块重击' },
  { no: 'S03', at: 0.3, src: 'wh-fast', vol: 0.12, note: '截图卡浮入' },
  { no: 'S03', at: 1.6, src: 'scan', vol: 0.10, dur: 1.6, note: '扫描光带' },
  { no: 'S04', at: 0.1, src: 'pop', vol: 0.10, note: '标题花字' },
  { no: 'S04', word: 2, src: 'marker', vol: 0.10, dur: 1.2, note: '下划线划过' },
  { no: 'S05', at: 0.4, src: 'swoosh', vol: 0.10, note: '缩成气泡' },
  { no: 'S06', at: 0.2, src: 'swoosh', vol: 0.11, note: '收口卡片' },
  { no: 'S06', at: 1.8, src: 'sparkle', vol: 0.12, note: '收尾点亮' },
];

export const BGM_VOLUME = 0.13;

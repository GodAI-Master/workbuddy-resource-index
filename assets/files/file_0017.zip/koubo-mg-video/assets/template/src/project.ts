// ═══════════════════════════════════════════════════════
// 项目配置 —— 每个新任务只改这个文件 + shots.ts
// ═══════════════════════════════════════════════════════
export const PROJECT = {
  // 品牌区（左上角顶栏）
  brand: 'WorkBuddy',
  tagline: '自媒体流水线',
  logo: '', // 放好 logo 后填 'textures/logo.png'；留空则只显示文字，不会 404

  // 素材（都放在 public/ 下）
  video: 'voice.mp4', // 口播底片（H.264 / yuv420p）
  audio: 'audio/voice.m4a', // 从底片抽出的口播音轨（单声道即可）

  // 视觉风格：paper（米白纸面工作室）/ ink（浅灰冷调）/ night（暗底霓虹）
  theme: 'paper' as 'paper' | 'ink' | 'night',

  // 人脸标定：口播底片里的脸中心像素坐标（1080×1920 坐标系）
  // 用 tools/probe.py 抽帧后目测填入；决定圆形气泡裁到哪
  face: { x: 540, y: 810 },

  // 字幕样式
  sub: {
    bandCenter: 0.92, // 字幕带中心在画面高度的百分比（0.92 = 很靠下部）
    maxFontSize: 50,
    highlight: 'amber' as 'amber' | 'green' | 'red', // 当前字的强调色
  },
} as const;

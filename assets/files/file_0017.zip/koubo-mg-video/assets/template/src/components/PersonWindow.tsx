import React from 'react';
import { AbsoluteFill, OffthreadVideo, interpolate, spring, useCurrentFrame, useVideoConfig, staticFile } from 'remotion';
import { C, FACE, IS_DARK } from '../theme';
import { PROJECT } from '../project';
import { WinCfg, SHOTS, shotByNo, WINDOWS } from '../timeline';

// 人像窗口：圆形气泡 / 竖版面板，始终直播口播底片（人物口型一直可见）
// 移动铁律：位置/大小切换只在镜头开头 12 帧内一步到位；
// 不允许在镜头中途连续漂移（观众会晕，而且显得廉价）
export const PersonWindow: React.FC<{ no: string; win: WinCfg; delayFrames?: number }> = ({ no, win, delayFrames = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const shot = shotByNo(no);
  const local = frame - shot.from;

  // 上一镜结束时的窗口位置 → 本镜从那儿滑/缩过来
  const prevShot = SHOTS.find((s) => s.to === shot.from);
  const prevWin = prevShot ? WINDOWS[prevShot.no] : undefined;
  const cxOf = (w: WinCfg) => (w.shape === 'circle' ? w.cx : w.side === 'right' ? 1080 - w.w / 2 - 44 : w.w / 2 + 44);
  const rOf = (w: WinCfg) => (w.shape === 'circle' ? w.r : w.w / 2);

  const fromCx = prevWin ? cxOf(prevWin) : 540;
  const fromCy = prevWin ? prevWin.cy : prevShot?.type === 'LIVE' ? 960 : win.cy;
  const fromR = prevWin ? rOf(prevWin) : prevShot?.type === 'LIVE' ? 560 : rOf(win);

  const toCx = cxOf(win);
  const toR = rOf(win);
  const toH = win.shape === 'circle' ? win.r * 2 : win.h;

  const moveP = interpolate(local, [0, 12], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const cx = fromCx + (toCx - fromCx) * moveP;
  const cy = fromCy + (win.cy - fromCy) * moveP;
  const r = fromR + (toR - fromR) * moveP;

  // 轻微点头 + 呼吸缩放，避免"贴纸感"
  const nod = Math.sin(local / 9) * 3;
  const breath = 1 + Math.sin(local / 14) * 0.009;
  const pop = spring({ frame: local - delayFrames, fps, config: { damping: 14, mass: 0.7 }, durationInFrames: 14 });

  // 衔接方式分三种，做错就会"两个人同时出现"：
  //   ① 上一镜是 LIVE（全屏人）→ 无缝缩过来：透明度保持 1，只缩半径和位移
  //      （这里若做淡入，第 0–5 帧就是一个巨大的半透明人 + 右下小气泡 = 双人物穿帮）
  //   ② 上一镜也是气泡/面板 → 无缝合位移，透明度 1
  //   ③ 这是第一个带窗口的镜头 → 才用弹入（scale + fade）
  const seamless = !!prevShot;
  const opacity = seamless ? 1 : pop;
  const scaleIn = seamless ? 1 : 0.86 + 0.14 * pop;

  const isCircle = win.shape === 'circle';
  const w = r * 2;
  const h = isCircle ? r * 2 : toH;
  // 底片裁剪：让脸落在窗口视觉中心（FACE 来自 src/project.ts 的标定）
  const cropW = isCircle ? r * 4.1 : r * 4.48;
  const s = w / cropW;
  const ring = IS_DARK ? '#2A2E34' : '#FFFDF8';

  return (
    <>
      {isCircle && (
        <>
          <div style={{
            position: 'absolute', left: cx - r - 12, top: cy - r - 12 + nod, width: (r + 12) * 2, height: (r + 12) * 2,
            borderRadius: '50%', border: `3px dashed ${C.amber}57`,
            transform: `rotate(${frame * 0.55}deg)`, opacity, zIndex: 19, pointerEvents: 'none',
          }} />
          <div style={{
            position: 'absolute', left: cx - r - 6, top: cy - r - 6 + nod, width: (r + 6) * 2, height: (r + 6) * 2,
            borderRadius: '50%', border: `2px solid ${C.green}33`,
            opacity, zIndex: 19, pointerEvents: 'none',
          }} />
          {[0, 1].map((k) => {
            const cyc = ((local + k * 45) % 90) / 90;
            const alpha = Math.round(0.3 * (1 - cyc) * 255).toString(16).padStart(2, '0');
            return (
              <div key={k} style={{
                position: 'absolute', left: cx - r * (1 + cyc * 0.22), top: cy - r * (1 + cyc * 0.22) + nod,
                width: r * 2 * (1 + cyc * 0.22), height: r * 2 * (1 + cyc * 0.22), borderRadius: '50%',
                border: `2px solid ${C.green}${alpha}`,
                opacity, zIndex: 19, pointerEvents: 'none',
              }} />
            );
          })}
        </>
      )}
      {!isCircle && (
        <svg width={w + 24} height={h + 24} style={{
          position: 'absolute', left: cx - w / 2 - 12, top: cy - h / 2 - 12 + nod, zIndex: 21, pointerEvents: 'none',
        }}>
          {([[0, 0, 1, 1], [w + 24, 0, -1, 1], [0, h + 24, 1, -1], [w + 24, h + 24, -1, -1]] as const).map(([px, py, sx, sy], i) => (
            <path key={i} d={`M ${px} ${py + sy * 30} L ${px} ${py} L ${px + sx * 30} ${py}`}
              fill="none" stroke={C.amber} strokeWidth={4} strokeLinecap="round" opacity={opacity * 0.85} />
          ))}
        </svg>
      )}
      <div style={{
        position: 'absolute', left: cx - w / 2, top: cy - h / 2 + nod,
        width: w, height: h,
        borderRadius: isCircle ? '50%' : 34, overflow: 'hidden',
        opacity, transform: `scale(${scaleIn * breath})`,
        border: `${isCircle ? 7 : 6}px solid ${ring}`,
        boxShadow: '0 18px 44px rgba(20,20,20,0.24)',
        zIndex: 20, background: '#DEDCD5',
      }}>
        <AbsoluteFill>
          <OffthreadVideo
            src={staticFile(PROJECT.video)}
            muted
            style={{
              width: 1080 * s, height: 1920 * s, position: 'absolute',
              left: w / 2 - FACE.x * s, top: h / 2 - FACE.y * s,
            }}
          />
        </AbsoluteFill>
        {local > 8 && local < 34 && (
          <AbsoluteFill style={{ overflow: 'hidden' }}>
            <div style={{
              position: 'absolute', top: -h, height: h * 3, width: w * 0.5,
              left: -w * 0.4 + ((local - 8) / 26) * w * 1.8, transform: 'rotate(16deg)',
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.55), transparent)',
              filter: 'blur(4px)',
            }} />
          </AbsoluteFill>
        )}
      </div>
    </>
  );
};

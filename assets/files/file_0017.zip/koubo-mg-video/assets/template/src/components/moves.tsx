import React from 'react';
import { AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { C, FONT } from '../theme';

// ═══════════════════════════════════════════════════════════════
// 招牌动效原语库 —— 参数化、与具体文案无关，任何口播片的镜头都能调
// 每个组件都写了「命门」：做错这一步，效果就从"高级"变成"廉价"
// ═══════════════════════════════════════════════════════════════

const clampI = (frame: number, a: number, b: number, from = 0, to = 1, ease = Easing.out(Easing.cubic)) =>
  interpolate(frame, [a, b], [from, to], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: ease });

// ─────────────────────────────────────────────────────────────
// 1. 圆心匹配虹膜切（Iris Cut）
// 上一个镜头的圆环圆心，本镜头从这里炸开，露出下一幕
// 命门：① 圆心必须与上一镜的环严格同心，差 20px 就假
//       ② 开圈要用 ease-in 加速外扩（不是匀速），才有"吸入"感
//       ③ 圆盘要随开圈"退成描边"，不能一直是个实心饼
// ─────────────────────────────────────────────────────────────
export const IrisCut: React.FC<{
  cx: number; cy: number;
  discText?: string;
  discColor?: string; discColor2?: string;
  discR?: number;
  startAt?: number;
  coverColor?: string;
  doneAt?: number;
}> = ({ cx, cy, discText = '', discColor = C.green, discColor2 = C.greenLight, discR = 150, startAt = 0, coverColor = C.bgDeep, doneAt = 27 }) => {
  const frame = useCurrentFrame() - startAt;
  const { fps } = useVideoConfig();
  // 接圆：r 从上一镜的环尺寸长到圆盘尺寸
  const jp = clampI(frame, 0, 8);
  const jr = discR * 0.27 + discR * 0.73 * jp;
  const irisP = clampI(frame, 8, 26, 0, 1, Easing.bezier(0.62, 0, 0.32, 1));
  const irisR = jr + irisP * 2600;
  const discP = spring({ frame: frame - 10, fps, config: { damping: 12 }, durationInFrames: 16 });
  const bounce = interpolate(frame, [14, 22, 32], [1, 1.32, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
  const discFade = interpolate(frame, [34, 48], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });

  return (
    <AbsoluteFill style={{ pointerEvents: 'none', zIndex: 30 }}>
      {frame < doneAt && (
        <AbsoluteFill style={{
          background: coverColor,
          WebkitMaskImage: `radial-gradient(circle ${irisR}px at ${cx}px ${cy}px, transparent 97%, black 100%)`,
          maskImage: `radial-gradient(circle ${irisR}px at ${cx}px ${cy}px, transparent 97%, black 100%)`,
        }} />
      )}
      {frame >= 8 && frame < 22 && (
        <div style={{
          position: 'absolute', left: cx - irisR - 8, top: cy - irisR - 8,
          width: (irisR + 8) * 2, height: (irisR + 8) * 2, borderRadius: '50%',
          border: `10px solid ${C.green}`, opacity: 0.5 * (1 - irisP), zIndex: 31,
        }} />
      )}
      {discR > 0 && (
        <div style={{
          position: 'absolute', left: cx - discR, top: cy - discR, width: discR * 2, height: discR * 2, zIndex: 32,
          opacity: discFade, transform: `scale(${(0.4 + 0.6 * jp) * bounce})`,
        }}>
          <div style={{
            width: '100%', height: '100%', borderRadius: '50%',
            background: `linear-gradient(135deg, ${discColor}, ${discColor2})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 20px 50px ${discColor}66`,
          }}>
            <span style={{ fontFamily: FONT, fontWeight: 900, fontSize: discR * 1.0, color: '#fff', transform: `scale(${discP})`, lineHeight: 1 }}>
              {discText}
            </span>
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
};

// ─────────────────────────────────────────────────────────────
// 2. 互动翻面揭示（Flip Reveal）
// 一列条目，说到第 k 个词的瞬间，第 k 张卡从侧面翻正
// 命门：① 起始角 88° 不是 180°（180° 会看到背面，很廉价）
//       ② 随角度做 brightness 衰减，模拟金属反光扫过
//       ③ transformOrigin 必须固定在一侧，翻起来才像"铰链"
// ─────────────────────────────────────────────────────────────
export interface FlipItem { label: string; desc?: string; color?: string; mark?: string }

export const FlipList: React.FC<{
  items: FlipItem[];
  times: number[]; // 每条的翻面起始帧（镜头本地帧），来自 wordTimes(...).start - shot.from
  x: number; y: number; w: number; h: number; gap?: number;
  dir?: 'left' | 'right';
}> = ({ items, times, x, y, w, h, gap = 14, dir = 'left' }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: w }}>
      {items.map((it, i) => {
        const lf = times[Math.min(i, times.length - 1)] ?? 0;
        const f = frame - lf;
        const p = f < 0 ? 0 : spring({ frame: f, fps, config: { damping: 15 }, durationInFrames: 20 });
        const ang = 88 * (1 - p);
        const bright = 1 - 0.28 * Math.abs(Math.sin((ang * Math.PI) / 180));
        const col = it.color ?? C.ink;
        return (
          <div key={it.label} style={{ height: h, marginBottom: gap, perspective: 1200, opacity: f < 0 ? 0 : 1 }}>
            <div style={{
              height: '100%', transformStyle: 'preserve-3d',
              transform: `rotateY(${dir === 'left' ? -ang : ang}deg)`,
              filter: `brightness(${bright})`,
              transformOrigin: dir === 'left' ? 'left center' : 'right center',
              background: C.card, border: '2.5px solid rgba(127,127,127,0.16)',
              borderRadius: 16, padding: '0 18px', display: 'flex', alignItems: 'center', gap: 16,
              boxShadow: '0 8px 20px rgba(20,20,20,0.10)',
            }}>
              {it.mark && (
                <div style={{
                  fontFamily: FONT, fontWeight: 900, fontSize: 20, color: col,
                  border: `2.5px solid ${col}`, borderRadius: 8, padding: '2px 7px', flexShrink: 0,
                }}>{it.mark}</div>
              )}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0 }}>
                <div style={{ fontFamily: FONT, fontWeight: 900, fontSize: Math.round(h * 0.36), color: col, lineHeight: 1.1 }}>{it.label}</div>
                {it.desc && <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: Math.round(h * 0.22), color: C.ink2, lineHeight: 1.2 }}>{it.desc}</div>}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// 3. SVG 描线追踪（Stair Trace）
// 一支笔实时画出阶梯，画完台阶按词卡点逐块落成
// 命门：① 用 pathLength={1} + dashoffset 描线，笔尖位置要自己算（不能只画线不给笔）
//       ② 笔尖必须被线"吃掉"—— 画过的部分才算数
//       ③ 台阶填充要错峰（每级差 2 帧），一起亮就是死的
// ─────────────────────────────────────────────────────────────
export const StairTrace: React.FC<{
  steps: number;
  x: number; y: number; stepW: number; stepH: number;
  drawFrom?: number; drawDur?: number;
  slabTexts?: string[];
  slabTimes?: number[];
  showNib?: boolean;
  color?: string;
}> = ({ steps, x, y, stepW, stepH, drawFrom = 10, drawDur = 36, slabTexts, slabTimes, showNib = true, color = C.ink }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  // 阶梯路径：一格横 + 一格竖；stepH 为负则向左上爬（更符合"往上走"的直觉）
  const pts: [number, number][] = [];
  for (let i = 0; i < steps; i++) {
    pts.push([x + i * stepW, y + i * stepH]);
    pts.push([x + (i + 1) * stepW, y + i * stepH]);
  }
  const baseY = stepH > 0 ? y + steps * stepH : y; // 台阶填充的基准底边
  const d = pts.map(([px, py], i) => `${i === 0 ? 'M' : 'L'} ${px} ${py}`).join(' ');
  const p = clampI(frame, drawFrom, drawFrom + drawDur, 0, 1, Easing.inOut(Easing.cubic));

  // 笔尖位置：按路径总长取当前点
  const segLen = (a: [number, number], b: [number, number]) => Math.hypot(b[0] - a[0], b[1] - a[1]);
  const total = pts.slice(1).reduce((acc, pt, i) => acc + segLen(pts[i], pt), 0);
  let target = total * p;
  let nib = pts[0];
  for (let i = 1; i < pts.length; i++) {
    const l = segLen(pts[i - 1], pts[i]);
    if (target <= l) {
      const t = l === 0 ? 0 : target / l;
      nib = [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t];
      break;
    }
    target -= l;
    nib = pts[i];
  }

  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0 }}>
        {Array.from({ length: steps }).map((_, i) => {
          const fp = clampI(frame, drawFrom + drawDur - 6 + i * 2, drawFrom + drawDur + 4 + i * 2, 0, 1);
          const ry = y + i * stepH;
          return (
            <rect key={i} x={x + i * stepW} y={ry} width={stepW} height={Math.abs(baseY - ry)}
              fill={C.greenBg} opacity={fp * 0.9} />
          );
        })}
        <path d={d} fill="none" stroke={color} strokeWidth={6} strokeLinejoin="round"
          pathLength={1} strokeDasharray="1" strokeDashoffset={1 - p} />
      </svg>

      {showNib && frame >= drawFrom && frame <= drawFrom + drawDur + 2 && (
        <div style={{
          position: 'absolute', left: nib[0] - 11, top: nib[1] - 11, width: 22, height: 22, borderRadius: '50%',
          background: color, border: '4px solid #FFFDF8', boxShadow: '0 4px 10px rgba(20,20,20,0.35)',
        }} />
      )}

      {/* 台阶上的石板：说到第 k 个词时落下，但不能早于第 k 级台阶被画出来
          （否则石板会孤零零飘在空白里，等台阶来"接住"它） */}
      {slabTexts?.map((tx, i) => {
        const spoken = slabTimes?.[Math.min(i, (slabTimes?.length ?? 1) - 1)] ?? 0;
        const drawn = drawFrom + (drawDur / steps) * (i + 0.6);
        const at = Math.max(spoken, drawn);
        const sp = spring({ frame: frame - at, fps, config: { damping: 13, mass: 0.8 }, durationInFrames: 16 });
        if (frame < at) return null;
        const bx = x + i * stepW + 14;
        const by = y + i * stepH - 96;
        return (
          <div key={tx} style={{
            position: 'absolute', left: bx, top: by, width: stepW - 28, height: 92,
            background: C.card, borderRadius: 12, border: '2.5px solid rgba(127,127,127,0.16)',
            boxShadow: '0 10px 24px rgba(20,20,20,0.16)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            opacity: sp, transform: `translateY(${(1 - sp) * -46}px) scale(${0.9 + 0.1 * sp})`,
          }}>
            <span style={{ fontFamily: FONT, fontWeight: 900, fontSize: Math.min(30, Math.round((stepW - 40) / Math.max(tx.length, 1) * 1.25)), color: C.ink, whiteSpace: 'nowrap' }}>{tx}</span>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

// ─────────────────────────────────────────────────────────────
// 4. 孔版印刷冲击（Riso Slam）
// 双色油墨套印，字先错位抖动，再硬切套准
// 命门：① 用 mixBlendMode:'multiply' 才像油墨叠印，普通半透明是塑料感
//       ② 抖动是"阻尼振荡"（cos*exp 衰减），不是随机抖动
//       ③ 套准必须是硬切（那一帧偏移归零 + 1 帧 3% 脉冲），渐渐归零就软了
// ─────────────────────────────────────────────────────────────
export const RisoSlam: React.FC<{
  text: string;
  size?: number;
  y?: number;
  slamAt?: number;
  regFrame?: number;
  stamp?: string;
}> = ({ text, size = 300, y = 950, slamAt = 12, regFrame = 58, stamp = '已套准' }) => {
  const frame = useCurrentFrame();
  const slam = clampI(frame, slamAt, slamAt + 8, 0, 1, Easing.in(Easing.cubic));
  const t = Math.max(0, frame - slamAt - 8);
  const decay = Math.cos((2 * Math.PI * t) / 18) * Math.exp(-t / 60);
  const off = frame < slamAt + 8 || frame >= regFrame ? { x: 0, y: 0 } : { x: 20 * decay, y: 8 * -decay };
  const pulse = frame === regFrame ? 1.03 : frame === regFrame + 1 ? 1.015 : 1;

  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      <div style={{
        position: 'absolute', left: 0, right: 0, top: y - 70, height: size * 1.6,
        background: '#F5F1E4', borderTop: '3px solid #DDD8C6', borderBottom: '3px solid #DDD8C6',
        boxShadow: '0 18px 50px rgba(20,20,20,0.22)', opacity: slam,
      }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: y + slam * -80, textAlign: 'center', opacity: slam, transform: `scale(${pulse})` }}>
        <span style={{
          position: 'absolute', left: 0, right: 0, top: 0,
          fontFamily: FONT, fontWeight: 900, fontSize: size, letterSpacing: '0.02em',
          color: C.risoA, mixBlendMode: 'multiply', transform: `translate(${-off.x}px, ${-off.y}px)`,
        }}>{text}</span>
        <span style={{
          position: 'absolute', left: 0, right: 0, top: 0,
          fontFamily: FONT, fontWeight: 900, fontSize: size, letterSpacing: '0.02em',
          color: C.risoB, mixBlendMode: 'multiply', transform: `translate(${off.x}px, ${off.y}px)`,
        }}>{text}</span>
        <span style={{ position: 'relative', fontFamily: FONT, fontWeight: 900, fontSize: size, letterSpacing: '0.02em', color: 'transparent' }}>{text}</span>
      </div>
      {frame >= regFrame + 2 && (
        <div style={{
          position: 'absolute', right: 90, top: y - 30, width: 130, height: 130, borderRadius: '50%',
          border: `6px solid ${C.greenDeep}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'rgba(255,253,247,0.85)', transform: 'rotate(10deg)',
          fontFamily: FONT, fontWeight: 900, fontSize: 30, color: C.greenDeep,
        }}>{stamp}</div>
      )}
    </AbsoluteFill>
  );
};

// ─────────────────────────────────────────────────────────────
// 5. 聚光主角卡（Spotlight）
// 关灯，只有一束光落在主卡上，光池先游走再锁定卡心
// 命门：① 暗场用 SVG evenodd 挖孔（box-shadow 挖不出圆角孔）
//       ② 光池要"游走 2–3 站再锁"，直接锁 = 没有叙事
//       ③ 卡要轻微抬升（lift）+ 呼吸（bob），静态卡在暗场里像贴纸
// ─────────────────────────────────────────────────────────────
export const Spotlight: React.FC<{
  x: number; y: number; w: number; h: number; r?: number;
  lightStops?: [number, number][];
  lockAt?: number;
  dim?: number;
  children?: React.ReactNode;
}> = ({ x, y, w, h, r = 36, lightStops = [[240, 700], [520, 1100], [520, 980]], lockAt = 26, dim = 0.9, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const lit = clampI(frame, 0, lockAt, 0, 1);
  const lift = clampI(frame, lockAt, lockAt + 18);
  const bob = Math.sin(frame / 16) * 3 * lit;

  // 光池位置：按 lightStops 逐站插值，最后一站是卡心
  const stops = [...lightStops.slice(0, -1), [x + w / 2, y + h / 2] as [number, number]];
  const seg = (stops.length - 1) || 1;
  const sp = Math.min(lit * seg, seg - 0.0001);
  const i = Math.floor(sp);
  const lt = sp - i;
  const lx = stops[i][0] + (stops[Math.min(i + 1, stops.length - 1)][0] - stops[i][0]) * lt;
  const ly = stops[i][1] + (stops[Math.min(i + 1, stops.length - 1)][1] - stops[i][1]) * lt;

  const rr = (x0: number, y0: number, w0: number, h0: number, rad: number) =>
    `M${x0 + rad} ${y0} H${x0 + w0 - rad} Q${x0 + w0} ${y0} ${x0 + w0} ${y0 + rad} V${y0 + h0 - rad} Q${x0 + w0} ${y0 + h0} ${x0 + w0 - rad} ${y0 + h0} H${x0 + rad} Q${x0} ${y0 + h0} ${x0} ${y0 + h0 - rad} V${y0 + rad} Q${x0} ${y0} ${x0 + rad} ${y0} Z`;

  return (
    <>
      <div style={{
        position: 'absolute', left: x, top: y - lift * 70 + bob, width: w, height: h, borderRadius: r,
        background: C.card, overflow: 'hidden', zIndex: 6,
        boxShadow: '0 30px 70px rgba(0,0,0,0.42)',
        transform: `scale(${1 + 0.02 * lift})`,
      }}>{children}</div>
      {/* 香槟色轮廓光 */}
      <div style={{
        position: 'absolute', left: x - 4, top: y - 4 - lift * 70 + bob, width: w + 8, height: h + 8, borderRadius: r + 4,
        border: '3px solid #E8C97A', opacity: 0.55 * lift, zIndex: 7, pointerEvents: 'none',
        boxShadow: '0 0 40px rgba(232,201,122,0.45)',
      }} />
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, zIndex: 8, opacity: lit, pointerEvents: 'none' }}>
        <defs>
          <radialGradient id="sp-pool" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(0,0,0,0)" />
            <stop offset="70%" stopColor="rgba(0,0,0,0)" />
            <stop offset="100%" stopColor={`rgba(10,9,7,${dim * 0.55})`} />
          </radialGradient>
        </defs>
        <path d={`M0 0 H1080 V1920 H0 Z ${rr(x, y - lift * 70 + bob, w, h, r)}`} fillRule="evenodd" fill={`rgba(12,11,9,${dim})`} />
        <circle cx={lx} cy={ly} r={260} fill="url(#sp-pool)" opacity={0.5 * (1 - lit)} />
      </svg>
    </>
  );
};

// ─────────────────────────────────────────────────────────────
// 6. 主题切换扫场（Theme Sweep）
// 一条斜向晨昏线扫过全屏，左暗右亮（或反过来），完成明暗/主题切换
// 命门：用 clip-path 做硬边，边缘留 1 道高光；渐隐变量做"慢扫"
// ─────────────────────────────────────────────────────────────
export const ThemeSweep: React.FC<{
  from: string; to: string;
  startAt?: number; dur?: number;
  angle?: number; // 斜度（deg），-12 左右最自然
  children?: React.ReactNode;
}> = ({ from, to, startAt = 0, dur = 30, angle = -12, children }) => {
  const frame = useCurrentFrame();
  const p = clampI(frame, startAt, startAt + dur, 0, 1, Easing.inOut(Easing.cubic));
  const edge = -20 + p * 140; // 百分比
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ background: from }}>{children}</AbsoluteFill>
      <AbsoluteFill style={{
        background: to,
        clipPath: `polygon(0 0, ${edge}% 0, ${edge - angle * 0.9}% 100%, 0 100%)`,
      }} />
      <AbsoluteFill style={{
        left: `${edge - 3}%`, width: '3%', top: 0, bottom: 0,
        background: 'linear-gradient(90deg, rgba(255,255,255,0), rgba(255,255,255,0.5), rgba(255,255,255,0))',
        transform: `skewX(${angle}deg)`, opacity: p > 0.02 && p < 0.98 ? 1 : 0,
      }} />
    </AbsoluteFill>
  );
};

// ─────────────────────────────────────────────────────────────
// 7. 粒子场（Particle Field）
// mode='gather'：从四周向中心汇聚（提炼/归纳）
// mode='burst'：从中心向外迸发（点亮/通电/高潮）
// 命门：粒子必须用确定性伪随机（mulberry32），否则每帧闪
// ─────────────────────────────────────────────────────────────
const rnd = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

export const Particles: React.FC<{
  count?: number; mode?: 'gather' | 'burst';
  cx: number; cy: number;
  startAt?: number; dur?: number;
  seed?: number; color?: string; spread?: number;
}> = ({ count = 28, mode = 'burst', cx, cy, startAt = 0, dur = 34, seed = 7, color = C.green, spread = 520 }) => {
  const frame = useCurrentFrame();
  const p = clampI(frame, startAt, startAt + dur, 0, 1, Easing.out(Easing.cubic));
  const r = rnd(seed);
  const ps = Array.from({ length: count }, () => ({
    a: r() * Math.PI * 2, sp: 0.4 + r() * 0.6, sz: 4 + r() * 8, lag: r() * 0.25,
  }));
  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      {ps.map((pt, i) => {
        const lp = Math.max(0, Math.min(1, (p - pt.lag) / (1 - pt.lag)));
        const dist = (mode === 'burst' ? lp : 1 - lp) * spread * pt.sp;
        const x = cx + Math.cos(pt.a) * dist;
        const y = cy + Math.sin(pt.a) * dist;
        const o = mode === 'burst' ? 1 - lp : lp;
        if (frame < startAt) return null;
        return (
          <div key={i} style={{
            position: 'absolute', left: x - pt.sz / 2, top: y - pt.sz / 2,
            width: pt.sz, height: pt.sz, borderRadius: pt.sz / 2,
            background: color, opacity: o * 0.85,
          }} />
        );
      })}
    </AbsoluteFill>
  );
};

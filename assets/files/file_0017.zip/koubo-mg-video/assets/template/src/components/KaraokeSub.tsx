import React from 'react';
import { interpolate, useCurrentFrame } from 'remotion';
import { C, FONT } from '../theme';
import { PROJECT } from '../project';
import { SUBS, SubChar, H as STAGE_H, W as STAGE_W, shotAt, WINDOWS } from '../timeline';

// 逐字高亮卡拉OK字幕
// 时间完全来自真实语音对齐：开口才走字，静音处停住
// 位置在画面很靠下部（project.sub.bandCenter，默认 92% 高度）
const hotColor = () => {
  const k = PROJECT.sub.highlight;
  return k === 'green' ? C.greenDeep : k === 'red' ? C.red : C.amberDeep;
};

const currentSub = (frame: number) => {
  let cur = SUBS[0];
  for (const s of SUBS) {
    if (frame >= s.from - 3) cur = s;
    else break;
  }
  return cur;
};

// 右下有圆形气泡时，字幕要给气泡让位 —— 否则长句会压到人脸上
const rightPadFor = (frame: number) => {
  const shot = shotAt(frame);
  const w = WINDOWS[shot.no];
  if (w && w.shape === 'circle' && w.cy > 1300) {
    return Math.max(40, STAGE_W - (w.cx - w.r) + 16);
  }
  return 40;
};

export const KaraokeSub: React.FC = () => {
  const frame = useCurrentFrame();
  if (!SUBS.length) return null;
  const sub = currentSub(frame);
  const chars = sub.chars;
  if (!chars.length) return null;

  // 折行：优先在词尾（br）断行，每行 ≤16 字
  const lines: SubChar[][] = [];
  let cur: SubChar[] = [];
  chars.forEach((c) => {
    cur.push(c);
    if (cur.length >= 16 || (c.br && cur.length >= 6)) {
      lines.push(cur);
      cur = [];
    }
  });
  if (cur.length) {
    if (lines.length && lines[lines.length - 1].length + cur.length <= 18) {
      lines[lines.length - 1] = [...lines[lines.length - 1], ...cur];
    } else lines.push(cur);
  }

  const maxLen = Math.max(...lines.map((l) => l.length));
  const padR = rightPadFor(frame);
  const avail = STAGE_W - 40 - padR;
  const fs = Math.min(PROJECT.sub.maxFontSize, Math.floor(avail / maxLen * 1.0));
  const lineH = fs * 1.32;
  const bandH = lines.length * lineH + 26;
  const top = Math.round(PROJECT.sub.bandCenter * STAGE_H) - bandH / 2;

  const enter = interpolate(frame, [sub.from - 3, sub.from + 3], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  const hot = hotColor();

  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, top,
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
      paddingLeft: 40, paddingRight: padR,
      opacity: enter, zIndex: 40, pointerEvents: 'none',
    }}>
      {lines.map((line, li) => (
        <div key={li} style={{
          display: 'flex', alignItems: 'baseline',
          background: 'rgba(253,252,248,0.86)', borderRadius: 18,
          padding: `${lineH * 0.14}px ${fs * 0.42}px`,
          boxShadow: '0 6px 20px rgba(20,20,20,0.10)',
          backdropFilter: 'blur(6px)',
        }}>
          {line.map((c, ci) => {
            const active = frame >= c.start && frame < c.end;
            const done = frame >= c.end;
            // 逐字弹跳：到字时上弹并回弹，颜色由灰转墨
            const pop = active
              ? interpolate(frame, [c.start, c.start + 2, c.start + 7], [0, 1, 0.35], { extrapolateRight: 'clamp' })
              : 0;
            return (
              <span key={ci} style={{
                fontFamily: FONT, fontWeight: 900, fontSize: fs, lineHeight: 1.15,
                display: 'inline-block',
                color: active ? hot : done ? C.ink : '#A9ABA2',
                transform: active ? `scale(${1 + pop * 0.16}) translateY(${-pop * 5}px)` : 'none',
                transformOrigin: 'center bottom',
                textShadow: active ? `0 2px 12px ${hot}66` : 'none',
                marginRight: ci === line.length - 1 ? 0 : fs * 0.06,
              }}>
                {c.ch}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

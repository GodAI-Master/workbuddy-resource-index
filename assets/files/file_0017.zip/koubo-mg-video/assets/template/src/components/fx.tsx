import React from 'react';
import { Easing, interpolate, useCurrentFrame } from 'remotion';
import { C, FONT } from '../theme';
const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

// ═══════════════════════════════════════════════════════
// 强调/装饰动效元件（对应《动画特效与音效大全》第 9.3 表）
// 全部确定性、无随机时钟；delay 用镜头本地帧，便于卡真实字位
// ═══════════════════════════════════════════════════════

const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

/* 手绘圈选：椭圆描线一笔画完 */
export const CircleMark: React.FC<{
  x: number; y: number; w: number; h: number; delay: number; dur?: number;
  color?: string; stroke?: number; rot?: number;
}> = ({ x, y, w, h, delay, dur = 16, color = C.amber, stroke = 6, rot = -3 }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.inOut(Easing.quad) });
  const rx = w / 2;
  const ry = h / 2;
  // 手绘感：轻微不闭合的椭圆
  const d = `M ${rx * 1.02} ${ry}
             C ${rx * 1.02} ${ry * 0.42}, ${rx * 0.52} ${-ry * 0.06}, 0 ${-ry * 0.02}
             C ${-rx * 0.56} ${ry * 0.02}, ${-rx * 1.04} ${ry * 0.46}, ${-rx * 0.98} ${ry * 1.02}
             C ${-rx * 0.9} ${ry * 1.62}, ${-rx * 0.2} ${ry * 2.04}, ${rx * 0.42} ${ry * 1.98}`;
  return (
    <svg width={w} height={h * 1.2} viewBox={`${-w / 2} 0 ${w} ${h * 1.2}`}
      style={{ position: 'absolute', left: x - w / 2, top: y, transform: `rotate(${rot}deg)`, pointerEvents: 'none', overflow: 'visible' }}>
      <path d={d} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
        pathLength={1} strokeDasharray="1" strokeDashoffset={1 - p} />
    </svg>
  );
};

/* 马克笔划线：标题下横向拖出 */
export const Underline: React.FC<{ x: number; y: number; w: number; delay: number; dur?: number; color?: string; thick?: number }> = ({
  x, y, w, delay, dur = 12, color = C.amberBg, thick = 22,
}) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w * p, height: thick, borderRadius: 6,
      background: color, transform: 'skewX(-8deg)', pointerEvents: 'none',
    }} />
  );
};

/* 箭头指示：曲线描出 + 箭头尖 */
export const ArrowCue: React.FC<{
  x1: number; y1: number; x2: number; y2: number; delay: number; dur?: number;
  color?: string; stroke?: number; bend?: number;
}> = ({ x1, y1, x2, y2, delay, dur = 14, color = C.amberDeep, stroke = 7, bend = 0.28 }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const mx = (x1 + x2) / 2 + (y2 - y1) * bend;
  const my = (y1 + y2) / 2 - (x2 - x1) * bend;
  const d = `M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`;
  const ang = Math.atan2(y2 - my, x2 - mx) * 180 / Math.PI;
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'visible' }}>
      <path d={d} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
        pathLength={1} strokeDasharray="1" strokeDashoffset={1 - p} />
      {p > 0.92 && (
        <g transform={`translate(${x2} ${y2}) rotate(${ang})`} opacity={interpolate(frame, [dur, dur + 4], [0, 1], clamp)}>
          <path d="M0 0 L-26 -13 L-26 13 Z" fill={color} />
        </g>
      )}
    </svg>
  );
};

/* 关键词描边框：四角描入 + 轻微脉冲 */
export const FocusFrame: React.FC<{
  x: number; y: number; w: number; h: number; delay: number; dur?: number;
  color?: string; stroke?: number; pulse?: boolean;
}> = ({ x, y, w, h, delay, dur = 14, color = C.amber, stroke = 5, pulse = true }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const beat = pulse ? 1 + Math.sin(Math.max(0, frame - dur) / 7) * 0.012 : 1;
  const arm = 34;
  const g = stroke;
  const corners = [
    [0, 0, 1, 1], [w, 0, -1, 1], [0, h, 1, -1], [w, h, -1, -1],
  ];
  return (
    <svg width={w + 20} height={h + 20} style={{ position: 'absolute', left: x - 10, top: y - 10, pointerEvents: 'none', overflow: 'visible', transform: `scale(${beat})`, transformOrigin: 'center' }}>
      <g transform="translate(10 10)">
        {corners.map(([cx, cy, sx, sy], i) => (
          <path key={i}
            d={`M ${cx} ${cy + sy * arm * p} L ${cx} ${cy} L ${cx + sx * arm * p} ${cy}`}
            fill="none" stroke={color} strokeWidth={g} strokeLinecap="round" />
        ))}
      </g>
    </svg>
  );
};

/* 柱状图升起 + 数值滚动 */
export const Bars: React.FC<{
  x: number; y: number; w: number; h: number;
  items: { label: string; v: number }[]; delay: number; stagger?: number; dur?: number;
  color?: string; colorAlt?: string; dark?: boolean;
}> = ({ x, y, w, h, items, delay, stagger = 5, dur = 14, color = C.green, colorAlt = C.greenLight, dark }) => {
  const frame = useCurrentFrame() - delay;
  const max = Math.max(...items.map((i) => i.v));
  const bw = w / items.length;
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: w, height: h }}>
      {items.map((it, i) => {
        const p = interpolate(frame, [i * stagger, i * stagger + dur], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
        const bh = (it.v / max) * (h - 54) * p;
        return (
          <div key={it.label} style={{ position: 'absolute', left: i * bw, bottom: 0, width: bw, textAlign: 'center' }}>
            <div style={{ fontFamily: FONT, fontWeight: 900, fontSize: 26, color: dark ? '#F0F0EC' : C.ink, marginBottom: 6, opacity: p }}>
              {Math.round(it.v * p)}
            </div>
            <div style={{
              width: bw * 0.56, height: bh, margin: '0 auto', borderRadius: '8px 8px 4px 4px',
              background: i % 2 === 0 ? `linear-gradient(180deg, ${colorAlt}, ${color})` : `linear-gradient(180deg, ${color}, ${color})`,
              boxShadow: '0 6px 16px rgba(23,178,106,0.22)',
            }} />
            <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 20, color: dark ? 'rgba(240,240,236,0.7)' : C.ink3, marginTop: 8 }}>{it.label}</div>
          </div>
        );
      })}
    </div>
  );
};

/* 数字滚动 */
export const CountUp: React.FC<{ from: number; to: number; delay: number; dur?: number; fontSize?: number; color?: string; suffix?: string; prefix?: string }> = ({
  from, to, delay, dur = 24, fontSize = 96, color = C.ink, suffix = '', prefix = '',
}) => {
  const frame = useCurrentFrame() - delay;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const v = from + (to - from) * p;
  const dec = to % 1 === 0 ? 0 : 1;
  return (
    <span style={{ fontFamily: FONT, fontWeight: 900, fontSize, color, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.01em' }}>
      {prefix}{v.toFixed(dec)}{suffix}
    </span>
  );
};

/* 拟声词/标签弹出：旋入 + 过冲 */
export const BurstTag: React.FC<{
  x: number; y: number; text: string; delay: number; color?: string; bg?: string;
  fontSize?: number; rot?: number; dark?: boolean;
}> = ({ x, y, text, delay, color = C.white, bg = C.ink, fontSize = 44, rot = -7, dark }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, 12], [0, 1], { ...clamp, easing: Easing.out(Easing.back(2.2)) });
  return (
    <div style={{
      position: 'absolute', left: x, top: y, opacity: Math.min(1, p * 2),
      transform: `rotate(${rot + (1 - p) * 12}deg) scale(${0.5 + p * 0.5})`,
      background: bg, color, borderRadius: 16, padding: `${fontSize * 0.24}px ${fontSize * 0.6}px`,
      fontFamily: FONT, fontWeight: 900, fontSize, letterSpacing: '0.02em',
      boxShadow: dark ? '0 12px 30px rgba(0,0,0,0.4)' : '0 12px 28px rgba(27,28,26,0.24)',
      border: `3px solid ${dark ? 'rgba(255,255,255,0.14)' : 'rgba(255,255,255,0.9)'}`,
      whiteSpace: 'nowrap',
    }}>{text}</div>
  );
};

/* 光扫过：一道斜向亮带 */
export const Sweep: React.FC<{ x: number; y: number; w: number; h: number; delay: number; dur?: number; color?: string; angle?: number }> = ({
  x, y, w, h, delay, dur = 18, color = 'rgba(255,255,255,0.75)', angle = 18,
}) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0 || frame > dur) return null;
  const p = interpolate(frame, [0, dur], [0, 1], clamp);
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w, height: h, overflow: 'hidden', pointerEvents: 'none',
    }}>
      <div style={{
        position: 'absolute', top: -h * 0.5, height: h * 2, width: w * 0.42,
        left: -w * 0.5 + p * w * 1.5, transform: `rotate(${angle}deg)`,
        background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
        filter: 'blur(6px)',
      }} />
    </div>
  );
};

/* 线条连接（两点间曲线生长） */
export const Connector: React.FC<{ x1: number; y1: number; x2: number; y2: number; delay: number; dur?: number; color?: string; stroke?: number; dashed?: boolean }> = ({
  x1, y1, x2, y2, delay, dur = 14, color = C.green, stroke = 5, dashed,
}) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.inOut(Easing.cubic) });
  const mx = (x1 + x2) / 2;
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'visible' }}>
      <path d={`M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`} fill="none" stroke={color}
        strokeWidth={stroke} strokeLinecap="round" strokeDasharray={dashed ? '12 10' : undefined}
        pathLength={dashed ? undefined : 1} strokeDashoffset={dashed ? 0 : 1 - p} opacity={dashed ? p : 1} />
      <circle cx={x2} cy={y2} r={7} fill={color} opacity={interpolate(frame, [dur, dur + 4], [0, 1], clamp)} />
    </svg>
  );
};

/* 背景装饰漂浮：光斑 + 小图形，营造呼吸感 */
export const Floaters: React.FC<{ count?: number; seed?: number; dark?: boolean; opacity?: number }> = ({
  count = 14, seed = 7, dark, opacity = 1,
}) => {
  const frame = useCurrentFrame();
  const rnd = mulberry32(seed);
  const items = Array.from({ length: count }, () => ({
    x: rnd() * 1080,
    y: rnd() * 1920,
    r: 60 + rnd() * 190,
    sp: 0.004 + rnd() * 0.01,
    ph: rnd() * Math.PI * 2,
    a: 0.06 + rnd() * 0.10,
    warm: rnd() > 0.5,
  }));
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', opacity, pointerEvents: 'none' }}>
      {items.map((it, i) => {
        const dx = Math.sin(frame * it.sp + it.ph) * 26;
        const dy = Math.cos(frame * it.sp * 0.8 + it.ph) * 20;
        return (
          <div key={i} style={{
            position: 'absolute', left: it.x - it.r / 2 + dx, top: it.y - it.r / 2 + dy,
            width: it.r, height: it.r, borderRadius: '50%',
            background: dark
              ? `radial-gradient(circle, rgba(255,255,255,${it.a * 0.5}) 0%, transparent 70%)`
              : it.warm
                ? `radial-gradient(circle, rgba(200,134,42,${it.a}) 0%, transparent 70%)`
                : `radial-gradient(circle, rgba(23,178,106,${it.a * 0.9}) 0%, transparent 70%)`,
            filter: 'blur(2px)',
          }} />
        );
      })}
    </div>
  );
};

/* 小圆点脉冲（强调点） */
export const PulseDot: React.FC<{ x: number; y: number; r?: number; color?: string; delay?: number }> = ({
  x, y, r = 10, color = C.green, delay = 0,
}) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = (frame % 40) / 40;
  return (
    <>
      <div style={{ position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: '50%', background: color }} />
      <div style={{
        position: 'absolute', left: x - r * (1 + p * 2.4), top: y - r * (1 + p * 2.4),
        width: r * 2 * (1 + p * 2.4), height: r * 2 * (1 + p * 2.4), borderRadius: '50%',
        border: `2px solid ${color}`, opacity: 0.55 * (1 - p),
      }} />
    </>
  );
};

// ═══════════ 丰富度扩展元件（批次增强：确定性、镜头本地帧、可 delay 卡字位） ═══════════

/* 关键词花字贴纸：旋入过冲 + 持续轻摆，用于 LIVE 伴随强调与留白点缀 */
export const Sticker: React.FC<{
  x: number; y: number; text: string; delay?: number;
  bg?: string; color?: string; rot?: number; fontSize?: number; icon?: string; dark?: boolean;
}> = ({ x, y, text, delay = 0, bg = C.card, color = C.ink, rot = -5, fontSize = 40, icon, dark }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, 12], [0, 1], { ...clamp, easing: Easing.out(Easing.back(2.1)) });
  const sway = Math.sin(Math.max(0, frame) / 16) * 1.6;
  return (
    <div style={{
      position: 'absolute', left: x, top: y, opacity: Math.min(1, p * 2),
      transform: `rotate(${rot + sway + (1 - p) * 14}deg) scale(${0.5 + p * 0.5})`,
      background: bg, color, borderRadius: 18, padding: `${fontSize * 0.28}px ${fontSize * 0.55}px`,
      fontFamily: FONT, fontWeight: 900, fontSize, letterSpacing: '0.02em', whiteSpace: 'nowrap',
      display: 'flex', alignItems: 'center', gap: fontSize * 0.3,
      border: `2.5px solid ${dark ? 'rgba(255,255,255,0.14)' : 'rgba(27,28,26,0.10)'}`,
      boxShadow: dark ? '0 12px 28px rgba(0,0,0,0.4)' : '0 12px 28px rgba(27,28,26,0.20)',
    }}>
      {icon && <span style={{ fontSize: fontSize * 0.9 }}>{icon}</span>}
      {text}
    </div>
  );
};

/* 要点条目：圆形徽章 + 主词 + 副文，stagger 横向滑入，填补右侧留白 */
export const BulletRow: React.FC<{
  x: number; y: number; w: number; main: string; sub?: string;
  delay?: number; active?: boolean; glyph?: string; dark?: boolean; fontSize?: number;
}> = ({ x, y, w, main, sub, delay = 0, active = true, glyph = '✓', dark, fontSize = 34 }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, 14], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w, display: 'flex', alignItems: 'center', gap: 18,
      opacity: p, transform: `translateX(${(1 - p) * 34}px)`,
    }}>
      <div style={{
        width: 52, height: 52, borderRadius: '50%', flexShrink: 0,
        background: active ? `linear-gradient(135deg, ${C.green}, ${C.greenLight})` : 'rgba(27,28,26,0.10)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: FONT, fontWeight: 900, fontSize: 26, color: active ? '#fff' : C.ink3,
      }}>{glyph}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        <div style={{ fontFamily: FONT, fontWeight: 900, fontSize, color: dark ? '#F2F2EE' : C.ink, lineHeight: 1.15 }}>{main}</div>
        {sub && <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: Math.round(fontSize * 0.62), color: dark ? 'rgba(242,242,238,0.62)' : C.ink3 }}>{sub}</div>}
      </div>
    </div>
  );
};

/* 圆形图标徽章：渐变底 + glyph + 下方标签，弹入 + 呼吸缩放 */
export const IconChip: React.FC<{
  x: number; y: number; size?: number; glyph: string; label?: string;
  delay?: number; color?: string; fontSize?: number;
}> = ({ x, y, size = 124, glyph, label, delay = 0, color = C.green, fontSize = 34 }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, 14], [0, 1], { ...clamp, easing: Easing.out(Easing.back(1.8)) });
  const breath = 1 + Math.sin(Math.max(0, frame) / 12) * 0.03;
  return (
    <div style={{ position: 'absolute', left: x - size / 2, top: y, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, opacity: p, transform: `scale(${(0.7 + p * 0.3) * breath})` }}>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: `linear-gradient(135deg, ${color}, ${C.greenLight})`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: FONT, fontWeight: 900, fontSize, color: '#fff',
        boxShadow: `0 14px 30px ${C.greenBg}`,
      }}>{glyph}</div>
      {label && <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 26, color: C.ink2, whiteSpace: 'nowrap' }}>{label}</div>}
    </div>
  );
};

/* 流动虚线箭头：路径生长 + 沿线光点流动 + 末端箭头，承接两卡因果关系 */
export const FlowLine: React.FC<{
  x1: number; y1: number; x2: number; y2: number; delay?: number; dur?: number;
  color?: string; stroke?: number; dashed?: boolean;
}> = ({ x1, y1, x2, y2, delay = 0, dur = 16, color = C.green, stroke = 6, dashed = true }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, dur], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const bend = 0.22;
  const mx = (x1 + x2) / 2 + (y2 - y1) * bend;
  const my = (y1 + y2) / 2 - (x2 - x1) * bend;
  const ang = Math.atan2(y2 - my, x2 - mx) * 180 / Math.PI;
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'visible' }}>
      {dashed ? (
        <path d={`M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray="16 13" strokeDashoffset={-frame * 2.4} opacity={p} />
      ) : (
        <path d={`M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          pathLength={1} strokeDasharray="1" strokeDashoffset={1 - p} />
      )}
      {p > 0.9 && (
        <g transform={`translate(${x2} ${y2}) rotate(${ang})`} opacity={interpolate(frame, [dur, dur + 5], [0, 1], clamp)}>
          <path d="M0 0 L-28 -15 L-28 15 Z" fill={color} />
        </g>
      )}
    </svg>
  );
};

/* 星芒簇：围绕某点确定性散布四角星，按相位交替闪烁，强调高光落点 */
export const Sparkles: React.FC<{
  x: number; y: number; count?: number; seed?: number; delay?: number; color?: string; spread?: number;
}> = ({ x, y, count = 6, seed = 7, delay = 0, color = C.amber, spread = 120 }) => {
  const frame = useCurrentFrame() - delay;
  const rnd = mulberry32(seed);
  const stars = Array.from({ length: count }, () => ({
    dx: (rnd() - 0.5) * spread * 2,
    dy: (rnd() - 0.5) * spread * 2,
    ph: rnd() * Math.PI * 2,
    sz: 8 + rnd() * 12,
  }));
  if (frame < 0) return null;
  return (
    <div style={{ position: 'absolute', left: x, top: y, pointerEvents: 'none' }}>
      {stars.map((s, i) => {
        const op = 0.35 + 0.65 * Math.max(0, Math.sin(frame / 7 + s.ph));
        return (
          <svg key={i} width={s.sz * 2} height={s.sz * 2} style={{ position: 'absolute', left: s.dx - s.sz, top: s.dy - s.sz, opacity: op }}>
            <path d={`M ${s.sz} 0 L ${s.sz * 1.25} ${s.sz * 0.75} L ${s.sz * 2} ${s.sz} L ${s.sz * 1.25} ${s.sz * 1.25} L ${s.sz} ${s.sz * 2} L ${s.sz * 0.75} ${s.sz * 1.25} L 0 ${s.sz} L ${s.sz * 0.75} ${s.sz * 0.75} Z`} fill={color} />
          </svg>
        );
      })}
    </div>
  );
};

/* 小统计卡：标签 + 数字滚动 + 单位，弹入，填补留白并给出量化信息层 */
export const StatCard: React.FC<{
  x: number; y: number; w: number; h: number; label: string; from: number; to: number;
  unit?: string; delay?: number; accent?: string; dark?: boolean;
}> = ({ x, y, w, h, label, from, to, unit = '', delay = 0, accent = C.greenDeep, dark }) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, 14], [0, 1], { ...clamp, easing: Easing.out(Easing.back(1.6)) });
  const np = interpolate(frame, [6, 30], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const v = from + (to - from) * np;
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 26,
      background: dark ? C.darkCard : C.card, opacity: p,
      transform: `translateY(${(1 - p) * 40}px) scale(${0.94 + p * 0.06})`,
      boxShadow: dark ? 'none' : '0 18px 40px rgba(27,28,26,0.14)',
      border: dark ? `2px solid ${C.darkLine}` : '2px solid rgba(27,28,26,0.08)',
      padding: '24px 30px', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 10,
    }}>
      <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 26, color: dark ? 'rgba(242,242,238,0.6)' : C.ink3 }}>{label}</div>
      <div style={{ fontFamily: FONT, fontWeight: 900, fontSize: 64, color: dark ? '#F2F2EE' : accent, fontVariantNumeric: 'tabular-nums', lineHeight: 1.1 }}>
        {Math.round(v)}{unit}
      </div>
    </div>
  );
};

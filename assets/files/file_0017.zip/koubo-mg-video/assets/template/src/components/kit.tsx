import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig, staticFile, Img } from 'remotion';
import { C, FONT, EASE, IS_DARK } from '../theme';
import { PROJECT } from '../project';
import { ACT_STATIONS } from '../shots';
import { Floaters } from './fx';

// ───────── 确定性伪随机 ─────────
export const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

// ───────── 纸面工作室背景 ─────────
export const StudioBG: React.FC<{ dark?: boolean; enter?: number; noise?: boolean }> = ({ dark, enter = 0, noise = true }) => {
  const frame = useCurrentFrame();
  const o = enter > 0 ? interpolate(frame, [0, enter], [0, 1], { extrapolateRight: 'clamp' }) : 1;
  return (
    <AbsoluteFill style={{ opacity: o }}>
      <AbsoluteFill style={{
        background: dark
          ? `radial-gradient(120% 90% at 50% 30%, #23262B 0%, ${C.dark} 58%, #121316 100%)`
          : `radial-gradient(130% 100% at 50% 24%, #F4F2EC 0%, ${C.bg} 55%, ${C.bgDeep} 100%)`,
      }} />
      {noise && (
        <AbsoluteFill style={{
          backgroundImage: `radial-gradient(${dark ? 'rgba(255,255,255,0.045)' : 'rgba(27,28,26,0.05)'} 1px, transparent 1px)`,
          backgroundSize: '26px 26px',
          opacity: 0.5,
        }} />
      )}
      {/* 漂浮光斑（呼吸感） */}
      <Floaters count={12} seed={dark ? 31 : 11} dark={dark} opacity={dark ? 0.7 : 0.85} />
      {/* 地面接影 */}
      <AbsoluteFill style={{
        background: dark
          ? 'linear-gradient(to top, rgba(0,0,0,0.35), transparent 30%)'
          : 'linear-gradient(to top, rgba(27,28,26,0.07), transparent 26%)',
      }} />
    </AbsoluteFill>
  );
};

// ───────── 幽灵大标题（左上大黑字标题卡） ─────────
export const GhostTitle: React.FC<{ title: string; sub?: string; delay?: number; y?: number; size?: number; dark?: boolean; marker?: boolean }> = ({
  title, sub, delay = 2, y = 268, size = 104, dark, marker,
}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [delay, delay + 16], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
  const mk = marker ? interpolate(frame, [delay + 12, delay + 22], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) }) : 0;
  return (
    <div style={{ position: 'absolute', left: 64, top: y, zIndex: 5 }}>
      <div style={{
        fontFamily: FONT, fontWeight: 900, fontSize: size, lineHeight: 1.12, letterSpacing: '0.01em',
        color: dark ? '#F2F2EE' : C.ink,
        opacity: p, transform: `translateY(${(1 - p) * 44}px)`, filter: `blur(${(1 - p) * 10}px)`,
        textShadow: dark ? 'none' : '0 2px 0 rgba(255,255,255,0.6)',
      }}>
        {title}
        {marker && (
          <span style={{ position: 'absolute', left: 4, bottom: -14, width: `${title.length * size * 0.96}px`, maxWidth: '100%', height: 22, background: C.amberBg, transformOrigin: 'left', transform: `scaleX(${mk})`, borderRadius: 6 }} />
        )}
      </div>
      {sub && (
        <div style={{
          fontFamily: FONT, fontWeight: 700, fontSize: 36, color: dark ? 'rgba(242,242,238,0.72)' : C.ink2,
          marginTop: 18, opacity: interpolate(frame, [delay + 8, delay + 20], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
          transform: `translateY(${(1 - p) * 24}px)`,
        }}>
          —— {sub}
        </div>
      )}
    </div>
  );
};

// ───────── 白色浮卡 ─────────
export const WhiteCard: React.FC<{ x: number; y: number; w: number; h: number; r?: number; rot?: number; children?: React.ReactNode; style?: React.CSSProperties; shadow?: string }> = ({
  x, y, w, h, r = 26, rot = 0, children, style, shadow,
}) => (
  <div style={{
    position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: r,
    background: C.card, transform: `rotate(${rot}deg)`, overflow: 'hidden',
    boxShadow: shadow ?? '0 22px 48px rgba(27,28,26,0.14), 0 4px 12px rgba(27,28,26,0.08)',
    ...style,
  }}>
    {children}
  </div>
);

// 进度环
export const Ring: React.FC<{ size: number; progress: number; stroke?: number; color?: string; track?: string }> = ({
  size, progress, stroke = 10, color = C.green, track = 'rgba(27,28,26,0.12)',
}) => {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
        strokeDasharray={`${progress * circ} ${circ}`}
      />
    </svg>
  );
};

// 印章
export const Stamp: React.FC<{ x: number; y: number; size?: number; text: string; sub?: string; color?: string; delay?: number; rip?: boolean; fontSize?: number }> = ({
  x, y, size = 168, text, sub, color = C.amberDeep, delay = 0, rip = true, fontSize,
}) => {
  const frame = useCurrentFrame() - delay;
  if (frame < 0) return null;
  const p = interpolate(frame, [0, 9], [0, 1], { extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
  const scale = 1.65 - 0.65 * p + (frame < 12 ? (1 - interpolate(frame, [9, 12], [0, 1], { extrapolateRight: 'clamp' })) * 0.06 : 0);
  const ripR = rip ? interpolate(frame, [6, 24], [size * 0.5, size * 1.15], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }) : 0;
  const ripO = rip ? interpolate(frame, [6, 24], [0.5, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }) : 0;
  const fs = fontSize ?? (text.length >= 4 ? size * 0.21 : size * 0.30);
  return (
    <div style={{ position: 'absolute', left: x - size / 2, top: y - size / 2, width: size, height: size }}>
      {rip && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: ripR * 2, height: ripR * 2, borderRadius: '50%', border: `3px solid ${color}`, opacity: ripO }} />
      </div>}
      <div style={{
        width: '100%', height: '100%', borderRadius: '50%', border: `6px solid ${color}`,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        background: 'rgba(255,253,247,0.88)', transform: `scale(${scale}) rotate(-8deg)`,
        boxShadow: '0 10px 26px rgba(27,28,26,0.16)', overflow: 'hidden',
      }}>
        <div style={{ fontFamily: FONT, fontWeight: 900, fontSize: fs, color, lineHeight: 1.1, letterSpacing: '0.02em', whiteSpace: 'nowrap' }}>{text}</div>
        {sub && <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: fs * 0.5, color, opacity: 0.85, marginTop: 4 }}>{sub}</div>}
      </div>
    </div>
  );
};

// 标签 pill
export const Pill: React.FC<{ x: number; y: number; w?: number; text: string; dark?: boolean; active?: boolean; fontSize?: number; delay?: number; children?: React.ReactNode; style?: React.CSSProperties }> = ({
  x, y, w, text, dark, active, fontSize = 34, delay = 0, children, style,
}) => {
  const frame = useCurrentFrame() - delay;
  const p = interpolate(frame, [0, 10], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.back(1.6)) });
  return (
    <div style={{
      position: 'absolute', left: x, top: y, padding: '16px 34px', borderRadius: 999,
      background: active ? C.greenBg : dark ? C.darkCard : C.card,
      border: `2.5px solid ${active ? C.green : dark ? C.darkLine : C.line}`,
      fontFamily: FONT, fontWeight: 800, fontSize, color: active ? C.greenDeep : dark ? '#E8E8E4' : C.ink2,
      whiteSpace: 'nowrap', opacity: Math.min(1, p), transform: `translateY(${(1 - p) * 26}px) scale(${0.92 + 0.08 * p})`,
      boxShadow: dark ? 'none' : '0 10px 24px rgba(27,28,26,0.10)',
      ...style,
    }}>
      {children ?? text}
    </div>
  );
};

// 品牌顶栏
export const TopBrand: React.FC<{ dark?: boolean; from?: number }> = ({ dark, from = 9 }) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [from, from + 12], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const isDark = dark ?? IS_DARK;
  return (
    <div style={{ position: 'absolute', left: 52, top: 64, display: 'flex', alignItems: 'center', gap: 18, opacity: o, zIndex: 8 }}>
      {PROJECT.logo ? (
        <Img src={staticFile(PROJECT.logo)} style={{ width: 66, height: 66, borderRadius: 16, boxShadow: isDark ? '0 0 0 1px rgba(255,255,255,0.15)' : '0 4px 14px rgba(27,28,26,0.15)' }} />
      ) : (
        <div style={{ width: 66, height: 66, borderRadius: 16, background: `linear-gradient(135deg, ${C.green}, ${C.greenLight})` }} />
      )}
      <div style={{ fontFamily: FONT }}>
        <div style={{ fontWeight: 900, fontSize: 30, color: isDark ? '#F0F0EC' : C.ink, letterSpacing: '0.02em' }}>{PROJECT.brand}</div>
        {PROJECT.tagline && (
          <div style={{ fontWeight: 700, fontSize: 20, color: isDark ? 'rgba(240,240,236,0.6)' : C.ink3, letterSpacing: '0.14em', marginTop: 2 }}>{PROJECT.tagline}</div>
        )}
      </div>
    </div>
  );
};

// 顶部进度 rail：01 爆款拆解 / 02 八层脚本 / 03 串起来跑
export const ProgressRail: React.FC<{ act: number; from?: number }> = ({ act, from = 14 }) => {
  const frame = useCurrentFrame();
  const stations = ACT_STATIONS.map((s) => ({ n: s.n, label: s.label, a: s.act }));
  return (
    <div style={{ position: 'absolute', left: 0, right: 0, top: 178, display: 'flex', justifyContent: 'center', gap: 22, zIndex: 8 }}>
      {stations.map((st, i) => {
        const d0 = from + i * 6;
        const o = interpolate(frame, [d0, d0 + 10], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
        const on = act >= st.a;
        const hit = act === st.a;
        return (
          <div key={st.n} style={{
            display: 'flex', alignItems: 'center', gap: 10, opacity: o,
            transform: `translateY(${(1 - o) * -18}px)`,
            padding: '9px 20px', borderRadius: 999,
            background: hit ? C.ink : 'rgba(255,255,255,0.72)',
            border: `2px solid ${hit ? C.ink : 'rgba(27,28,26,0.14)'}`,
            transition: 'none',
          }}>
            <span style={{ fontFamily: FONT, fontWeight: 900, fontSize: 22, color: hit ? '#fff' : C.ink3, fontVariantNumeric: 'tabular-nums' }}>{st.n}</span>
            <span style={{ fontFamily: FONT, fontWeight: 800, fontSize: 23, color: hit ? '#fff' : on ? C.ink2 : C.ink3 }}>{st.label}</span>
            {hit && <span style={{ width: 10, height: 10, borderRadius: 5, background: C.green }} />}
          </div>
        );
      })}
    </div>
  );
};

// 字幕行辅助：把台词按词边界折行（每行 ≤ 行宽）
export const wrapLines = (chars: { ch: string; br?: boolean }[], maxPerLine: number): number[][] => {
  const lines: number[][] = [];
  let cur: number[] = [];
  let start = 0;
  for (let i = 0; i < chars.length; i++) {
    cur.push(i);
    if (chars[i].br && cur.length >= Math.min(6, maxPerLine - 4)) {
      lines.push(cur); cur = []; start = i + 1;
    } else if (cur.length >= maxPerLine && chars.slice(start).some((c) => c.br)) {
      // 找 cur 内最后一个 br
      let lastBr = -1;
      cur.forEach((idx, k) => { if (chars[idx].br && k < cur.length - 3) lastBr = k; });
      if (lastBr >= 0) {
        lines.push(cur.slice(0, lastBr + 1));
        cur = cur.slice(lastBr + 1);
        start = cur[0];
      }
    }
  }
  if (cur.length) lines.push(cur);
  return lines;
};

export const springish = (frame: number, dur = 12, back = 1.5) =>
  interpolate(frame, [0, dur], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.back(back)) });

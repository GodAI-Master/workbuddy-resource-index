import React from 'react';
import { AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, staticFile, useCurrentFrame } from 'remotion';
import { C, FONT, IS_DARK } from './theme';
import { PROJECT } from './project';
import { SHOTS, TOTAL, FPS, W, H, SFX, BGM_VOLUME, shotAt, WINDOWS, personWinAt } from './timeline';
import { TopBrand, ProgressRail } from './components/kit';
import { PersonWindow } from './components/PersonWindow';
import { KaraokeSub } from './components/KaraokeSub';
import { SCENES } from './scenes';

// 只在 shots.ts 里配了 WINDOWS 的镜头才出现人像窗
const WindowSlot: React.FC<{ no: string }> = ({ no }) =>
  WINDOWS[no] ? <PersonWindow no={no} win={personWinAt(no)} /> : null;

// ═══ 主合成：底片 → 场景 → 人像窗 → 品牌栏 → 字幕 → 声音 ═══
// 图层顺序不能乱：字幕永远最上；品牌栏在人像窗之下（不挡脸）
export const Video: React.FC<{ bgm?: boolean }> = ({ bgm = true }) => {
  const frame = useCurrentFrame();
  const shot = shotAt(frame);
  const Scene = SCENES[shot.no];

  return (
    <AbsoluteFill style={{ background: C.bg, fontFamily: FONT }}>
      {/* 底层：口播底片。LIVE 镜头直接看它；MG/ASSET 被场景的不透明背景盖住 */}
      <AbsoluteFill>
        <OffthreadVideo src={staticFile(PROJECT.video)} muted style={{ width: W, height: H, objectFit: 'cover' }} />
      </AbsoluteFill>

      {/* 场景层：必须用 Sequence 包住，场景组件才拿得到「镜头本地帧」 */}
      <AbsoluteFill style={{ zIndex: 10 }}>
        {Scene ? (
          <Sequence from={shot.from} durationInFrames={shot.to - shot.from}>
            <Scene />
          </Sequence>
        ) : null}
      </AbsoluteFill>

      {/* 人像窗口（MG / ASSET） */}
      {shot.type !== 'LIVE' && <WindowSlot no={shot.no} />}

      <TopBrand dark={IS_DARK} />
      <ProgressRail act={shot.act} />
      <KaraokeSub />

      {/* 口播原声 */}
      <Audio src={staticFile(PROJECT.audio)} />

      {/* 动效音效：整体小音量，永远不抢口播 */}
      {SFX.map((cue, i) => (
        <Sequence key={i} from={cue.from} durationInFrames={cue.dur ?? undefined}>
          <Audio src={staticFile(`audio/sfx/${cue.src}.wav`)} volume={cue.volume} />
        </Sequence>
      ))}

      {/* BGM 低音量铺底 */}
      {bgm && <Audio src={staticFile('audio/bgm.wav')} volume={BGM_VOLUME} loop />}
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="Video"
      component={Video}
      durationInFrames={TOTAL}
      fps={FPS}
      width={W}
      height={H}
      defaultProps={{ bgm: true }}
    />
    <Composition
      id="VideoNoBgm"
      component={Video}
      durationInFrames={TOTAL}
      fps={FPS}
      width={W}
      height={H}
      defaultProps={{ bgm: false }}
    />
  </>
);

// ═══════════════════════════════════════════════════════
// 视觉 tokens —— 三套预设主题，由 project.ts 的 theme 切换
// 原则：底色是"纸/布"质感的低饱和面，内容靠白卡 + 墨色字 + 一个强调色撑起
// ═══════════════════════════════════════════════════════
import { PROJECT } from './project';

export interface Palette {
  bg: string; bgDeep: string; paper: string; card: string; line: string;
  ink: string; ink2: string; ink3: string;
  green: string; greenDeep: string; greenLight: string; greenBg: string;
  amber: string; amberDeep: string; amberBg: string;
  risoA: string; risoB: string;
  dark: string; darkCard: string; darkLine: string;
  red: string; white: string;
}

// 米白纸面工作室（教程 / 知识 / 工具类最稳）
const PAPER: Palette = {
  bg: '#ECEAE4', bgDeep: '#E2DFD7', paper: '#F7F5EF', card: '#FFFFFF', line: '#DDD9CE',
  ink: '#1B1C1A', ink2: '#4C4E49', ink3: '#8B8D86',
  green: '#17B26A', greenDeep: '#0E9455', greenLight: '#7FD858', greenBg: 'rgba(23,178,106,0.10)',
  amber: '#C8862A', amberDeep: '#9C6614', amberBg: 'rgba(200,134,42,0.12)',
  risoA: '#E4438C', risoB: '#2456C4',
  dark: '#191B1E', darkCard: '#22252A', darkLine: 'rgba(255,255,255,0.10)',
  red: '#D14B3D', white: '#FFFFFF',
};

// 冷灰办公（B 端 / SaaS / 效率类）
const INK: Palette = {
  bg: '#E9EBEE', bgDeep: '#DDE0E5', paper: '#F4F6F8', card: '#FFFFFF', line: '#D5DAE0',
  ink: '#14181D', ink2: '#414A55', ink3: '#7D8794',
  green: '#0F9B8E', greenDeep: '#0A7A70', greenLight: '#5FD3C6', greenBg: 'rgba(15,155,142,0.10)',
  amber: '#3B6FE0', amberDeep: '#2551B8', amberBg: 'rgba(59,111,224,0.10)',
  risoA: '#F2643C', risoB: '#2B4ECF',
  dark: '#101418', darkCard: '#191F26', darkLine: 'rgba(255,255,255,0.10)',
  red: '#D9453B', white: '#FFFFFF',
};

// 暗底霓虹（科技 / AI / 新品发布）
const NIGHT: Palette = {
  bg: '#15171B', bgDeep: '#101215', paper: '#1C1F24', card: '#22262C', line: 'rgba(255,255,255,0.12)',
  ink: '#F2F3F0', ink2: '#C3C7CC', ink3: '#8A9099',
  green: '#3BD98A', greenDeep: '#22A968', greenLight: '#8CF0B8', greenBg: 'rgba(59,217,138,0.12)',
  amber: '#F0B44A', amberDeep: '#D9932A', amberBg: 'rgba(240,180,74,0.14)',
  risoA: '#FF5FA2', risoB: '#4E7BFF',
  dark: '#0C0E11', darkCard: '#181B20', darkLine: 'rgba(255,255,255,0.10)',
  red: '#FF6B5B', white: '#FFFFFF',
};

const PALETTES: Record<string, Palette> = { paper: PAPER, ink: INK, night: NIGHT };
export const C: Palette = PALETTES[PROJECT.theme] ?? PAPER;

export const IS_DARK = PROJECT.theme === 'night';

export const FONT = '"Source Han Sans SC","Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif';
export const MONO = '"JetBrains Mono","Consolas","Courier New",monospace';

// 动效性格 tokens
export const EASE = {
  out: 'cubic-bezier(0.16,1,0.3,1)',
  inOut: 'cubic-bezier(0.65,0,0.35,1)',
  overshoot: 'cubic-bezier(0.34,1.56,0.64,1)',
  slam: 'cubic-bezier(0.55,0,0.2,1)',
} as const;

// 口播底片人脸标定（决定圆形气泡/竖版面板裁到哪）
export const FACE = PROJECT.face;

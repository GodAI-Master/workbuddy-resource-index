import { shotByNo, wordTimes, subByNo, type Shot } from '../timeline';

// ── 场景通用小工具 ─────────────────────────────────────────
// 场景组件拿到的 frame 是「镜头本地帧」（Root 用 Sequence 包过），
// 而 wordTimes / SUBS 给的是全片帧，所以要减掉镜头起点。

export const localShot = (no: string): Shot => shotByNo(no);

/** 每个词在镜头内的起声帧：逐词卡点（石板、列表、翻面）都从这里取 */
export const wordFramesLocal = (no: string): number[] => {
  const s = shotByNo(no);
  return wordTimes(no).map((w) => w.start - s.from);
};

/** 第 k 个词（超界取最后一个）*/
export const wordAt = (no: string, i: number): string => {
  const arr = wordTimes(no);
  return arr[Math.min(i, arr.length - 1)]?.w ?? '';
};

/** 某个字符在镜头内的起声帧（比词更细，用于单字强调）*/
export const charFrameLocal = (no: string, idx: number): number => {
  const sub = subByNo(no);
  const s = shotByNo(no);
  const c = sub.chars[Math.min(idx, sub.chars.length - 1)];
  return (c?.start ?? s.from) - s.from;
};

/** 整句字幕在镜头内的起止帧 */
export const subSpanLocal = (no: string): [number, number] => {
  const sub = subByNo(no);
  const s = shotByNo(no);
  return [sub.from - s.from, sub.to - s.from];
};

import React from 'react';
import { S01, S02, S03, S04, S05, S06 } from './starter';

// 镜头号 → 场景组件。新增镜头时在这里注册。
// 没注册的镜头会在画面里留空（Root 会跳过），所以每镜都必须有实现。
export const SCENES: Record<string, React.FC> = {
  S01, S02, S03, S04, S05, S06,
};

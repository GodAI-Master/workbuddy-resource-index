import React from 'react';
import { AbsoluteFill, Img, interpolate, Easing, staticFile, useCurrentFrame, useVideoConfig, spring } from 'remotion';
import { C, FONT } from '../theme';
import { GhostTitle, StudioBG, WhiteCard, Pill } from '../components/kit';
import { BulletRow, Sticker, Sweep } from '../components/fx';
import { FlipList, StairTrace, Particles } from '../components/moves';
import { wordFramesLocal, localShot } from './util';

// ══════════════════════════════════════════════════════════════
// 镜头实现范式（3 种类型各一个标准写法）
//
// 铁律：
// 1. MG / ASSET 场景的第一层必须是 <StudioBG />（不透明背景）。
//    漏铺 = 透出底层全屏真人，和右下气泡人物「双人同屏」，是最致命的穿帮
// 2. 场景里一切动画都用「镜头本地帧」，不要手写绝对帧
// 3. 逐词卡点统一从 wordFramesLocal(no) 取，说话说到哪，画面动到哪
// 4. LIVE 场景是透明 overlay，只叠花字/贴纸，不能铺底
// ══════════════════════════════════════════════════════════════

// ───────── S01 · LIVE：全屏真人口播 + 花字（透明 overlay） ─────────
export const S01: React.FC = () => {
  const frame = useCurrentFrame();
  const w = wordFramesLocal('S01');
  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      {/* 顶部标题花字：说到第 2 个词才弹 */}
      <Sticker x={250} y={300} text="口播 · 自动加动画" delay={w[1] ?? 8} fontSize={40} rot={-2} />
      <BulletRow x={110} y={1560} w={620} main="画面跟着说话走" sub="说到哪 动到哪" delay={w[3] ?? 24} />
    </AbsoluteFill>
  );
};

// ───────── S02 · MG：翻面揭示，逐词落 ─────────
export const S02: React.FC = () => {
  const frame = useCurrentFrame();
  const w = wordFramesLocal('S02');
  const s = localShot('S02');
  return (
    <AbsoluteFill>
      <StudioBG />
      <GhostTitle title="跟着语音走" sub="说到就出现" delay={4} />
      <FlipList
        x={96}
        y={620}
        w={720}
        h={112}
        items={[
          { label: '第一层', desc: '钩子 · 前 3 秒', mark: '01', color: C.amberDeep },
          { label: '第二层', desc: '结构 · 痛点方案', mark: '02', color: C.ink },
          { label: '第三层', desc: '节奏 · 每段一个转折', mark: '03', color: C.greenDeep },
        ]}
        times={[w[1] ?? 10, w[2] ?? 30, w[3] ?? 50]}
      />
      {/* 收口 */}
      <div style={{
        position: 'absolute', left: 96, top: 1080, fontFamily: FONT, fontWeight: 800, fontSize: 34, color: C.ink3,
        opacity: interpolate(frame, [s.to - s.from - 40, s.to - s.from - 26], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
      }}>一句话 一层画面</div>
    </AbsoluteFill>
  );
};

// ───────── S03 · ASSET：截图当主视觉 + 空白区补动态内容 ─────────
// 把 public/textures/shot.png 换成你自己的截图即可。
// 关键手法：截图右侧的空白区不是"留白"，是要填动态信息的地方
export const S03: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = localShot('S03');
  const dur = s.to - s.from;
  const cIn = spring({ frame, fps, config: { damping: 14 }, durationInFrames: 14 });
  const rows = [
    { k: '读取页面', v: '已进入详情页', at: 12 },
    { k: '提取文案', v: '2 段 · 386 字', at: 22 },
    { k: '拆解维度', v: '钩子 / 结构 / 节奏', at: 32 },
  ];
  return (
    <AbsoluteFill>
      <StudioBG />
      <WhiteCard
        x={62} y={420} w={956} h={760} rot={-0.8}
        style={{ padding: 14, opacity: cIn, transform: `translateY(${(1 - cIn) * 60}px)` }}
      >
        <div style={{ position: 'relative', width: '100%', height: '100%' }}>
          {/* 截图区。有真实素材就换成 <Img src={staticFile('textures/shot.png')} .../> */}
          <div style={{
            position: 'absolute', left: 0, top: 0, width: '62%', height: '100%',
            background: '#F3F1EA', borderRadius: 14, border: '2px dashed rgba(127,127,127,0.28)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: FONT, fontWeight: 800, fontSize: 26, color: C.ink3,
          }}>替换成真实截图 / 录屏</div>

          {/* 右侧空白区：动态内容面板 */}
          <div style={{ position: 'absolute', left: '64%', right: '2%', top: '6%', bottom: '6%' }}>
            <div style={{ fontFamily: FONT, fontWeight: 900, fontSize: 24, color: C.ink3, letterSpacing: '0.08em', marginBottom: 16 }}>
              正在读取
            </div>
            {rows.map((r, i) => {
              const p = spring({ frame: frame - r.at, fps, config: { damping: 16 }, durationInFrames: 16 });
              if (frame < r.at) return null;
              return (
                <div key={r.k} style={{
                  padding: '12px 0', borderBottom: '2px solid rgba(127,127,127,0.12)',
                  opacity: p, transform: `translateX(${(1 - p) * 26}px)`,
                }}>
                  <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 19, color: C.ink3 }}>{r.k}</div>
                  <div style={{ fontFamily: FONT, fontWeight: 900, fontSize: 25, color: C.ink2 }}>{r.v}</div>
                </div>
              );
            })}
            {/* 进度条 */}
            <div style={{ marginTop: 18 }}>
              <div style={{ height: 14, borderRadius: 999, background: 'rgba(127,127,127,0.16)', overflow: 'hidden' }}>
                <div style={{
                  height: '100%', width: `${interpolate(frame, [8, dur - 20], [0, 100], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}%`,
                  background: `linear-gradient(90deg, ${C.greenDeep}, ${C.greenLight})`, borderRadius: 999,
                }} />
              </div>
            </div>
          </div>
          <Sweep x={0} y={0} w={900} h={700} delay={10} dur={26} color="rgba(255,255,255,0.6)" angle={12} />
        </div>
      </WhiteCard>
      <div style={{
        position: 'absolute', left: 0, right: 0, top: 1230, textAlign: 'center',
        fontFamily: FONT, fontWeight: 800, fontSize: 34, color: C.ink2,
        opacity: interpolate(frame, [16, 28], [0, 1], { extrapolateRight: 'clamp' }),
      }}>空白处 就是留给内容的位置</div>
    </AbsoluteFill>
  );
};

// ───────── S04 · MG：标题 + 下划线跟着词走 ─────────
export const S04: React.FC = () => {
  const frame = useCurrentFrame();
  const w = wordFramesLocal('S04');
  const mk = interpolate(frame, [w[1] ?? 10, (w[1] ?? 10) + 14], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic),
  });
  return (
    <AbsoluteFill>
      <StudioBG />
      <GhostTitle title="逐字高亮" sub="开口才走字" delay={4} />
      <div style={{ position: 'absolute', left: 96, top: 700, fontFamily: FONT, fontWeight: 900, fontSize: 72, color: C.ink }}>
        当前这个字会亮
        <span style={{
          position: 'absolute', left: 0, bottom: -18, height: 18, width: '100%',
          background: C.amberBg, borderRadius: 6, transformOrigin: 'left', transform: `scaleX(${mk})`,
        }} />
      </div>
      <Pill x={96} y={900} text="静音处 字不前进" delay={w[3] ?? 40} />
    </AbsoluteFill>
  );
};

// ───────── S05 · LIVE：全屏 + 一个贴纸提示 ─────────
export const S05: React.FC = () => {
  const frame = useCurrentFrame();
  const w = wordFramesLocal('S05');
  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      <Sticker x={610} y={520} text="缩成气泡" delay={w[2] ?? 20} fontSize={36} rot={4} bg={C.card} />
    </AbsoluteFill>
  );
};

// ───────── S06 · MG：描线阶梯 + 末块迸发 ─────────
export const S06: React.FC = () => {
  const frame = useCurrentFrame();
  const s = localShot('S06');
  const w = wordFramesLocal('S06');
  const dur = s.to - s.from;
  return (
    <AbsoluteFill>
      <StudioBG />
      {/* 绘图纸点阵 + 四角裁切标记：让"要画阶梯"这件事提前被预告，也填住空白 */}
      <div style={{
        position: 'absolute', left: 60, top: 520, width: 900, height: 1100,
        backgroundImage: 'radial-gradient(rgba(27,28,26,0.10) 1.5px, transparent 1.5px)',
        backgroundSize: '34px 34px',
        opacity: interpolate(frame, [0, 8], [0, 1], { extrapolateRight: 'clamp' }),
      }} />
      {([[60, 520], [960, 520], [60, 1620], [960, 1620]] as const).map(([cx, cy], i) => {
        const cp = interpolate(frame, [i * 2, i * 2 + 6], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
        return (
          <div key={i} style={{ position: 'absolute', left: cx - 26, top: cy - 26, width: 52, height: 52, opacity: cp * 0.6 }}>
            <div style={{ position: 'absolute', left: 24, top: 0, width: 4, height: 16, background: C.ink3 }} />
            <div style={{ position: 'absolute', left: 24, bottom: 0, width: 4, height: 16, background: C.ink3 }} />
            <div style={{ position: 'absolute', top: 24, left: 0, height: 4, width: 16, background: C.ink3 }} />
            <div style={{ position: 'absolute', top: 24, right: 0, height: 4, width: 16, background: C.ink3 }} />
          </div>
        );
      })}
      <GhostTitle title="一格不差" delay={2} />
      <StairTrace
        steps={4}
        x={120}
        y={1080}
        stepW={210}
        stepH={-110}
        drawFrom={4}
        drawDur={30}
        slabTexts={['对齐', '卡点', '落位', '收口']}
        slabTimes={w.slice(0, 4)}
      />
      <Particles count={24} mode="burst" cx={540} cy={1000} startAt={Math.max(0, dur - 40)} dur={26} spread={420} />
      {/* 收口：左对齐贴边，不要居中 —— 居中的长句会被右下气泡咬掉一截 */}
      <div style={{
        position: 'absolute', left: 96, top: 1500, width: 620,
        fontFamily: FONT, fontWeight: 800, fontSize: 34, lineHeight: 1.4, color: C.ink2,
        opacity: interpolate(frame, [14, 26], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
      }}>画面 字幕 口播<br />三者同拍</div>
    </AbsoluteFill>
  );
};

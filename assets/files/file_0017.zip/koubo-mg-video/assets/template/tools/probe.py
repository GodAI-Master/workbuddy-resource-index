# -*- coding: utf-8 -*-
"""
素材体检 —— 口播底片进工程前先量一遍，避免后面反复返工。

做三件事：
  1. 打印分辨率 / 时长 / 帧率 / 编码（编码不是 H.264 会提醒你转码，
     HEVC 10bit 在 Remotion 里 seek 很慢，而且容易出黑帧）
  2. 抽 3 帧（10% / 50% / 85%）到 analysis/face_check_*.jpg，
     用来看人脸在画面哪里 —— 这个坐标要填进 src/project.ts 的 face，
     它决定圆形气泡/竖版面板裁到哪
  3. 提示 shots.ts 的时长上限该怎么填

用法：
  python tools/probe.py                 # 用 src/project.ts 里的 video
  python tools/probe.py path/to/x.mp4
"""
import json
import os
import re
import subprocess
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(PROJ)


def sh(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace').stdout


def main():
    if len(sys.argv) > 1:
        video = sys.argv[1]
    else:
        cfg = open('src/project.ts', encoding='utf-8').read()
        m = re.search(r"video:\s*'([^']+)'", cfg)
        video = 'public/' + (m.group(1) if m else 'voice.mp4')

    if not os.path.exists(video):
        sys.exit(f'找不到视频：{video}\n先把口播底片放到 public/ 下，并改 src/project.ts 的 video 字段')

    info = sh(['ffprobe', '-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', video])
    d = json.loads(info)
    v = next((s for s in d['streams'] if s['codec_type'] == 'video'), None)
    if not v:
        sys.exit('这个文件里没有视频轨')
    dur = float(d['format'].get('duration', 0))
    w, h = int(v['width']), int(v['height'])
    num, den = v.get('r_frame_rate', '30/1').split('/')
    fps = float(num) / float(den or 1)
    codec = v.get('codec_name', '?')
    pix = v.get('pix_fmt', '?')
    has_audio = any(s['codec_type'] == 'audio' for s in d['streams'])

    print(f'文件   {video}')
    print(f'分辨率 {w}x{h}   时长 {dur:.2f}s   帧率 {fps:.2f}')
    print(f'编码   {codec} / {pix}')
    print(f'音轨   {"有" if has_audio else "无 —— 需要另配音轨！"}')

    if codec not in ('h264',):
        print(f'\n!! 编码是 {codec}，建议转成 H.264 再进工程（HEVC 10bit 在 Remotion 里 seek 慢且易黑帧）：')
        print(f'   ffmpeg -i "{video}" -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -an public/voice.mp4')
    if (w, h) != (1080, 1920):
        print(f'\n提示：底片不是 1080x1920。工程画布固定竖屏 1080x1920，'
              f'非 9:16 素材会被 cover 裁切；建议先确认构图。')

    os.makedirs('analysis', exist_ok=True)
    for tag, pos in (('head', 0.10), ('mid', 0.50), ('low', 0.85)):
        out = f'analysis/face_check_{tag}.jpg'
        sh(['ffmpeg', '-y', '-v', 'error', '-ss', f'{dur*pos:.2f}', '-i', video,
            '-frames:v', '1', '-update', '1', out])
        print(f'抽帧   {out}  ({dur*pos:.1f}s)')

    if has_audio:
        sh(['ffmpeg', '-y', '-v', 'error', '-i', video, '-vn', '-ac', '1', '-ar', '16000',
            '-c:a', 'aac', '-b:a', '128k', 'public/audio/voice.m4a'])
        print('音轨   -> public/audio/voice.m4a')

    print(f'''
下一步：
  1. 打开 analysis/face_check_mid.jpg，量出脸的像素中心坐标，填进 src/project.ts:
         face: {{ x: 540, y: 810 }}
     （竖屏口播常见在 x≈540、y≈760–860；脸偏上就给 y 小一点）
  2. 填 src/shots.ts 的镜头表，t1 最大不要超过 {dur:.2f}
  3. 跑 python tools/align.py，再 npx tsc --noEmit 检查类型''')


if __name__ == '__main__':
    main()

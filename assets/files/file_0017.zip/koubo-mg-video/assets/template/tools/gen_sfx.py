# -*- coding: utf-8 -*-
"""
程序化音效合成 —— 纯标准库实现，不依赖 numpy，也不含任何第三方音频素材。

为什么自己合成：
  1. 版权与来源干净，skill 可以直接分发
  2. 音色可调（同名换参数就是另一种性格），且随时可复现
  3. 体积小：24 个音效加起来不到 3MB

口播片音效设计原则：
  · 一律短（50–500ms），长过口播的一个字就糊
  · 高频多、低频克制 —— 低频会和男声基频打架
  · 音量在 shots.ts 里另行压制（0.08–0.20），这里只管音色

用法：
  python tools/gen_sfx.py              # 全部重生成
  python tools/gen_sfx.py pop click    # 只重做指定几个
  python tools/gen_sfx.py --bgm        # 只做 BGM
"""
import math
import os
import random
import struct
import sys
import wave

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SFX_DIR = os.path.join(PROJ, 'public', 'audio', 'sfx')
SR = 44100


# ───────────────────────── 基础信号工具 ─────────────────────────
def n_of(dur):
    return int(SR * dur)


def noise(dur, seed=0):
    r = random.Random(seed)
    return [r.uniform(-1, 1) for _ in range(n_of(dur))]


def env_ad(x, attack=0.004, curve=4.0):
    """attack 线性 + decay 指数"""
    n = len(x)
    na = max(1, int(SR * attack))
    out = [0.0] * n
    for i in range(n):
        if i < na:
            g = i / na
        else:
            g = math.exp(-curve * (i - na) / max(1, n - na))
        out[i] = x[i] * g
    return out


def fade(x, ms=6):
    k = max(1, int(SR * ms / 1000))
    x = x[:]
    for i in range(min(k, len(x))):
        g = i / k
        x[i] *= g
        x[-1 - i] *= g
    return x


def _alpha(fc):
    # 一阶 IIR 低通系数
    fc = max(30.0, min(fc, SR * 0.45))
    return 1 - math.exp(-2 * math.pi * fc / SR)


def lp(x, fc):
    a = _alpha(fc)
    y = [0.0] * len(x)
    s = 0.0
    for i, v in enumerate(x):
        s += a * (v - s)
        y[i] = s
    return y


def hp(x, fc):
    low = lp(x, fc)
    return [v - l for v, l in zip(x, low)]


def bandpass(x, f_lo, f_hi):
    """带通 = 低通(hi) - 低通(lo)，两个一阶 IIR，O(n)"""
    hi = lp(x, f_hi)
    lo = lp(x, f_lo)
    return [a - b for a, b in zip(hi, lo)]


def bandpass_sweep(x, f0_lo, f0_hi, f1_lo, f1_hi):
    """时变带通（whoosh 的核心）：两个低通的截止频率随进度扫描"""
    n = len(x)
    a_hi0, a_hi1 = _alpha(f0_hi), _alpha(f1_hi)
    a_lo0, a_lo1 = _alpha(f0_lo), _alpha(f1_lo)
    s_hi = s_lo = 0.0
    out = [0.0] * n
    inv = 1.0 / max(1, n - 1)
    for i, v in enumerate(x):
        t = i * inv
        s_hi += (a_hi0 + (a_hi1 - a_hi0) * t) * (v - s_hi)
        s_lo += (a_lo0 + (a_lo1 - a_lo0) * t) * (v - s_lo)
        out[i] = s_hi - s_lo
    return out


def sine_sweep(dur, f0, f1):
    n = n_of(dur)
    out = [0.0] * n
    ph = 0.0
    for i in range(n):
        f = f0 * (f1 / f0) ** (i / max(1, n - 1))
        ph += 2 * math.pi * f / SR
        out[i] = math.sin(ph)
    return out


def sine(freq, dur, phase=0.0):
    return [math.sin(2 * math.pi * freq * i / SR + phase) for i in range(n_of(dur))]


def mix(*parts):
    """等长对齐后相加"""
    n = max(len(p) for p in parts)
    out = [0.0] * n
    for p in parts:
        for i, v in enumerate(p):
            out[i] += v
    return out


def scale(x, g):
    return [v * g for v in x]


def norm(x, peak=0.9):
    m = max(abs(v) for v in x) or 1e-9
    k = peak / m
    return [v * k for v in x]


def save(name, x, peak=0.9, sr=SR):
    x = norm(x, peak)
    data = b''.join(struct.pack('<h', int(max(-1.0, min(1.0, v)) * 32767)) for v in x)
    path = os.path.join(SFX_DIR if sr == SR else os.path.join(PROJ, 'public', 'audio'), name + '.wav')
    with wave.open(path, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data)
    return path


# ───────────────────────── 音效配方 ─────────────────────────
def sfx_pop():
    """短促"啵"：正弦下滑 + 一点点击噪 —— 弹入类万能音"""
    d = 0.13
    body = env_ad(sine_sweep(d, 420, 170), 0.003, 5)
    tick = env_ad(noise(d, 11), 0.001, 24)
    return fade(mix(body, scale(tick, 0.35)))
def sfx_click():
    """UI 咔哒"""
    d = 0.05
    a = env_ad(hp(noise(d, 21), 1800), 0.0008, 26)
    b = env_ad(sine(1400, d), 0.0008, 30)
    return fade(mix(a, scale(b, 0.4)), 3)
def sfx_tick():
    """滴答：3.8kHz 极短"""
    d = 0.045
    a = env_ad(sine(3800, d), 0.0006, 34)
    b = env_ad(hp(noise(d, 31), 3000), 0.0005, 30)
    return fade(mix(a, scale(b, 0.3)), 2)
def sfx_snap():
    """卡点脆响"""
    d = 0.06
    a = env_ad(bandpass(noise(d, 41), 900, 7000), 0.0007, 24)
    b = env_ad(sine(900, d), 0.001, 22)
    return fade(mix(a, scale(b, 0.35)), 3)
def sfx_swoosh():
    """通用划过：带通扫过"""
    d = 0.30
    s = bandpass_sweep(noise(d, 51), 150, 600, 1100, 4400)
    return fade(env_ad(norm(s), 0.04, 2.0), 10)
def sfx_wh_fast():
    """快划过（卡片浮入）"""
    d = 0.20
    s = bandpass_sweep(noise(d, 61), 250, 1000, 1600, 6400)
    return fade(env_ad(norm(s), 0.015, 3.2), 8)
def sfx_wh_quick():
    """更快更短（转场切口）"""
    d = 0.14
    s = bandpass_sweep(noise(d, 62), 450, 1800, 2100, 8400)
    return fade(env_ad(norm(s), 0.008, 4.0), 6)
def sfx_sweep():
    """长扫（滑入 / 编辑感）"""
    d = 0.42
    s = mix(bandpass_sweep(noise(d, 63), 120, 500, 900, 3600),
            scale(bandpass_sweep(noise(d, 64), 300, 1200, 1500, 6000), 0.25))
    return fade(env_ad(norm(s), 0.07, 1.8), 14)
def sfx_bass():
    """低频冲击（重物落下 / 转折）"""
    d = 0.35
    a = env_ad(sine_sweep(d, 58, 46), 0.004, 3.6)
    b = env_ad(sine(116, d), 0.004, 5.0)
    return fade(mix(a, scale(b, 0.22)), 8)
def sfx_impact_big():
    """大冲击：低频 + 噪声爆 + 短尾"""
    d = 0.62
    body = env_ad(sine_sweep(d, 52, 42), 0.003, 3.0)
    hit = env_ad(bandpass(noise(d, 71), 200, 6000), 0.001, 12)
    tail = env_ad(bandpass(noise(d, 72), 400, 2500), 0.02, 2.2)
    return fade(norm(mix(body, scale(hit, 0.8), scale(tail, 0.18))), 12)
def sfx_hit_weak():
    """弱击（轻落位）"""
    d = 0.12
    a = env_ad(sine(220, d), 0.002, 18)
    b = env_ad(bandpass(noise(d, 81), 600, 5000), 0.001, 22)
    return fade(mix(a, scale(b, 0.4)), 4)
def sfx_drop():
    """金属小物落地：不谐和正弦组 + 噪声"""
    d = 0.20
    a = env_ad(sine(760, d), 0.001, 12)
    b = env_ad(sine(1140, d), 0.001, 14)
    c = env_ad(sine(1870, d), 0.001, 18)
    n = env_ad(hp(noise(d, 91), 1500), 0.0008, 26)
    return fade(mix(a, scale(b, 0.55), scale(c, 0.3), scale(n, 0.35)), 4)
def sfx_page():
    """翻纸：两段带通噪声"""
    a = env_ad(bandpass(noise(0.06, 101), 700, 3200), 0.01, 4)
    b = env_ad(bandpass(noise(0.10, 102), 500, 2600), 0.02, 3)
    return fade(norm(a + b), 6)
def sfx_paper_slide():
    """纸张滑动（长）"""
    d = 0.34
    s = bandpass(noise(d, 111), 400, 2400)
    n = len(s)
    out = [0.0] * n
    for i, v in enumerate(s):
        out[i] = v * (1 + 0.4 * math.sin(2 * math.pi * 23 * i / SR))
    return fade(env_ad(norm(out), 0.05, 2.0), 12)
def sfx_staple():
    """订书机 / 盖章：高频脆 + 低频闷"""
    d = 0.16
    a = env_ad(hp(noise(d, 121), 2200), 0.0006, 20)
    b = env_ad(sine(160, d), 0.002, 16)
    return fade(mix(a, scale(b, 0.7)), 4)
def sfx_marker():
    """记号笔摩擦（描线用）"""
    d = 0.40
    s = bandpass(noise(d, 131), 800, 3600)
    out = [0.0] * len(s)
    for i, v in enumerate(s):
        out[i] = v * (0.6 + 0.4 * abs(math.sin(2 * math.pi * 9 * i / SR)))
    return fade(env_ad(norm(out), 0.03, 1.6), 14)
def sfx_keyboard():
    """连打：6 次 click"""
    gap, cnt = 0.085, 6
    base = sfx_click()
    total = int(SR * (gap * cnt + 0.08))
    out = [0.0] * total
    r = random.Random(5)
    for i in range(cnt):
        c = scale(base, 0.7 + 0.3 * r.random())
        a = int(SR * i * gap)
        for j, v in enumerate(c):
            if a + j < total:
                out[a + j] += v
    return fade(norm(out), 8)
def sfx_type_soft():
    """单次软打字"""
    d = 0.08
    a = env_ad(bandpass(noise(d, 141), 500, 2600), 0.001, 22)
    b = env_ad(sine(320, d), 0.001, 26)
    return fade(mix(a, scale(b, 0.35)), 4)
def sfx_scan():
    """扫描：上扫 + 轻微抖动"""
    d = 0.60
    s = mix(scale(sine_sweep(d, 280, 2100), 0.5),
            scale(bandpass(noise(d, 151), 800, 5000), 0.35))
    out = [0.0] * len(s)
    for i, v in enumerate(s):
        out[i] = v * (0.7 + 0.3 * math.sin(2 * math.pi * 11 * i / SR))
    return fade(env_ad(norm(out), 0.04, 1.8), 12)
def sfx_powerup():
    """通电 / 能量上升（高潮用）"""
    d = 0.85
    s = mix(scale(sine_sweep(d, 180, 1250), 0.6),
            scale(sine_sweep(d, 360, 2500), 0.22),
            scale(bandpass(noise(d, 161), 500, 6000), 0.18))
    return fade(env_ad(norm(s), 0.10, 1.2), 16)
def sfx_sparkle():
    """亮点：几颗高频铃"""
    total = 0.45
    out = [0.0] * n_of(total)
    r = random.Random(171)
    for i in range(5):
        d = 0.18
        f = 2600 + r.random() * 3400
        s = mix(env_ad(sine(f, d), 0.001, 9), scale(env_ad(sine(f * 1.5, d), 0.001, 12), 0.3))
        a = n_of(0.02 + i * 0.055 + r.random() * 0.02)
        g = 0.55 + 0.45 * r.random()
        for j, v in enumerate(s):
            if a + j < len(out):
                out[a + j] += v * g
    return fade(norm(out), 10)
def sfx_shimmer():
    """闪烁密集版（共振 / 显影）"""
    total = 0.62
    out = [0.0] * n_of(total)
    r = random.Random(181)
    for i in range(11):
        d = 0.14
        f = 3000 + r.random() * 4200
        s = env_ad(sine(f, d), 0.001, 10)
        a = n_of(0.01 + i * 0.048)
        g = 0.3 + 0.7 * r.random()
        for j, v in enumerate(s):
            if a + j < len(out):
                out[a + j] += v * g
    return fade(norm(out), 10)
def sfx_lightsweep():
    """灯光扫过：低频到中频的柔和扫"""
    d = 0.70
    s = mix(scale(sine_sweep(d, 120, 900), 0.5),
            scale(bandpass(noise(d, 191), 300, 3000), 0.3))
    return fade(env_ad(norm(s), 0.12, 1.4), 18)
def sfx_msgpop():
    """消息提示：双音上行"""
    d = 0.20
    a = env_ad(sine(660, d), 0.002, 10)
    b = scale(env_ad(sine(990, d), 0.002, 8), 0.7)
    shift = n_of(0.07)
    out = a[:]
    for j, v in enumerate(b):
        if shift + j < len(out):
            out[shift + j] += v
    return fade(out, 4)


RECIPES = {
    'pop': sfx_pop, 'click': sfx_click, 'tick': sfx_tick, 'snap': sfx_snap,
    'swoosh': sfx_swoosh, 'wh-fast': sfx_wh_fast, 'wh-quick': sfx_wh_quick, 'sweep': sfx_sweep,
    'bass': sfx_bass, 'impact-big': sfx_impact_big, 'hit-weak': sfx_hit_weak, 'drop': sfx_drop,
    'page': sfx_page, 'paper-slide': sfx_paper_slide, 'staple': sfx_staple, 'marker': sfx_marker,
    'keyboard': sfx_keyboard, 'type-soft': sfx_type_soft, 'scan': sfx_scan, 'powerup': sfx_powerup,
    'sparkle': sfx_sparkle, 'shimmer': sfx_shimmer, 'lightsweep': sfx_lightsweep, 'msgpop': sfx_msgpop,
}


# ───────────────────────── BGM ─────────────────────────
def make_bgm(dur=16.0, sr=22050):
    """极简 lo-fi pad 循环：Am - F - C - G，四小节
    只做垫底（shots.ts 里 BGM_VOLUME 只有 0.13，本来就不该听清旋律）"""
    chords = [
        [220.00, 261.63, 329.63],   # Am
        [174.61, 220.00, 261.63],   # F
        [261.63, 329.63, 392.00],   # C
        [196.00, 246.94, 293.66],   # G
    ]
    bar = dur / len(chords)
    total = int(sr * dur)
    out = [0.0] * total
    for ci, ch in enumerate(chords):
        a0, b0 = int(sr * ci * bar), int(sr * (ci + 1) * bar)
        n = b0 - a0
        k = max(1, int(sr * 0.35))   # 慢起慢落，避免小节接缝"咔"
        for f in ch:
            for det in (-0.6, 0.0, 0.7):   # 轻微 detune 出厚度
                ph = 2 * math.pi * (f + det) / sr
                for i in range(n):
                    g = (i / k) if i < k else ((n - i) / k if i > n - k else 1.0)
                    out[a0 + i] += math.sin(ph * i) * g / (len(ch) * 3)
    # 柔化高频，做出"隔墙听"的距离感
    out = lp(out, 900)
    return norm(out, 0.6)


def main():
    os.makedirs(SFX_DIR, exist_ok=True)
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    only_bgm = '--bgm' in sys.argv

    if not only_bgm:
        names = args or list(RECIPES.keys())
        for n in names:
            fn = RECIPES.get(n)
            if not fn:
                print(f'  跳过未知音效 {n}')
                continue
            p = save(n, fn())
            print(f'  {n:12} {os.path.getsize(p)/1024:6.1f} KB')

    if only_bgm or not args:
        x = make_bgm()
        path = save('bgm', x, 0.9, sr=22050)
        print(f'  {"bgm":12} {os.path.getsize(path)/1024:6.1f} KB')

    print('done ->', os.path.relpath(SFX_DIR, PROJ))


if __name__ == '__main__':
    main()

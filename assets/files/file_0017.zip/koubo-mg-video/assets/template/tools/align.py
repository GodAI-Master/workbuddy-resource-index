# -*- coding: utf-8 -*-
"""
真实语音强制对齐 —— 让字幕/画面卡点跟着「真人怎么说的」走，而不是按字数平均分。

为什么必须这么做：
  按「镜头时长 ÷ 字数」平均分配，全片会漂移 0.5–2 秒，且每句漂移量不同。
  观众能立刻感觉到"字幕和嘴不同步"。真人说话有停顿、有快慢，只有能量 VAD
  能测出真实停顿在哪。

算法：
  1. 从口播底片抽 16k 单声道 wav，算 10ms 一帧的 RMS 能量
  2. 双阈值 VAD（噪声底 ×2.2 与峰值 ×0.14 取大）+ 填短静音 → 得到 N 个语音段
  3. 动态规划：把 N 个段切成「句数」个连续组，代价 = 每组语速密度对本片平均密度的偏离
     （偏离超 35% 重罚）→ 每句拿到它真正被说出来的那几个语音段
  4. 组内按段容量把 token 顺序消费掉 → 每个字拿到真实发音起止
  5. 反过来用首字起声重算镜头切点（提前 LEAD 秒切过去），画面/字幕/口播三者同拍

用法：
  python tools/align.py                  # 用 src/shots.ts 的镜头表
  python tools/align.py --dry            # 只打印诊断，不写文件

输出： src/align.json
"""
import array
import json
import math
import os
import re
import subprocess
import sys
import wave

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 16000
HOP = 160          # 10ms
LEAD = 0.14        # 镜头比人声提前多少秒切过去（观众才不觉得"迟"）
MINLEN = 0.70      # 单镜最短秒数

PUNCT = '，。、！？：；「」『』（）()《》——…·,.!?:;\'"'


def strip_punct(s):
    return ''.join(ch for ch in s if ch not in PUNCT and not ch.isspace())


def tokenize(text):
    """中文按单字，英文/数字按整词 —— 英文按字母拆会把 1 秒的词算成 9 个字，时间全乱"""
    toks, buf = [], ''
    for ch in text:
        if ch.isascii() and (ch.isalnum() or ch in '+&#.'):
            buf += ch
        else:
            if buf:
                toks.append(buf)
                buf = ''
            if ch.strip():
                toks.append(ch)
    if buf:
        toks.append(buf)
    return toks


def parse_shots():
    """从 src/shots.ts 解析镜头表（只取前 6 个字段，title/sub 可选）"""
    p = os.path.join(PROJ, 'src', 'shots.ts')
    src = open(p, encoding='utf-8').read()
    body = src.split('export const SHOTS_DEF')[1].split('];')[0]
    rows = []
    pat = re.compile(
        r"S\(\s*'([^']+)'\s*,\s*(\d+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*'(\w+)'\s*,\s*'([^']*)'")
    for m in pat.finditer(body):
        rows.append(dict(no=m.group(1), act=int(m.group(2)), t0=float(m.group(3)),
                         t1=float(m.group(4)), type=m.group(5), line=m.group(6)))
    if not rows:
        sys.exit('!! 没能从 src/shots.ts 解析出镜头。检查格式：S(\'S01\', 1, 0.00, 3.60, \'LIVE\', \'台词\')')
    return rows


# ───────────────────────── 音频能量 ─────────────────────────
def load_rms():
    """抽 16k 单声道 wav 再读。Windows 下 ffmpeg 直出管道不稳，且中文路径会出编码问题，
    所以先切工作目录、用相对路径、落盘再读。"""
    os.chdir(PROJ)
    os.makedirs('analysis', exist_ok=True)
    wav = 'analysis/voice16k.wav'
    audio = 'public/audio/voice.m4a'
    if not os.path.exists(audio):
        # 兜底：直接从底片抽
        cfg = open('src/project.ts', encoding='utf-8').read()
        m = re.search(r"video:\s*'([^']+)'", cfg)
        v = 'public/' + (m.group(1) if m else 'voice.mp4')
        subprocess.run(['ffmpeg', '-nostdin', '-y', '-v', 'error', '-i', v, '-vn',
                        '-ac', '1', '-ar', str(SR), '-c:a', 'pcm_s16le', wav], check=True)
    else:
        subprocess.run(['ffmpeg', '-nostdin', '-y', '-v', 'error', '-i', audio, '-vn',
                        '-ac', '1', '-ar', str(SR), '-c:a', 'pcm_s16le', wav], check=True)

    w = wave.open(wav, 'rb')
    s = array.array('h')
    s.frombytes(w.readframes(w.getnframes()))
    w.close()
    n = len(s) // HOP
    rms = []
    for i in range(n):
        base = i * HOP
        acc = 0
        for j in range(HOP):
            v = s[base + j]
            acc += v * v
        rms.append(math.sqrt(acc / HOP))
    return rms, len(s) / SR


def smooth(x, k=3):
    if k <= 1:
        return x[:]
    half = k // 2
    n = len(x)
    return [sum(x[max(0, i - half):min(n, i + half + 1)]) / (min(n, i + half + 1) - max(0, i - half)) for i in range(n)]


def pct(sorted_arr, p):
    if not sorted_arr:
        return 0.0
    return sorted_arr[min(int(len(sorted_arr) * p), len(sorted_arr) - 1)]


def vad(rms):
    sm = smooth(smooth(rms, 3), 5)
    srt = sorted(sm)
    noise, loud = pct(srt, 0.10), pct(srt, 0.92)
    th = max(noise * 2.2, loud * 0.14, 120)
    voiced = [1 if v > th else 0 for v in sm]

    def fill(arr, target, maxgap):
        out = arr[:]
        n, i = len(out), 0
        while i < n:
            if out[i] != target:
                j = i
                while j < n and out[j] != target:
                    j += 1
                if i > 0 and j < n and (j - i) < maxgap:
                    for k in range(i, j):
                        out[k] = target
                i = j
            else:
                i += 1
        return out

    voiced = fill(voiced, 1, 20)   # 填平 <200ms 的短静音（换气）
    voiced = fill(voiced, 0, 8)    # 剔掉 <80ms 的噪声
    return sm, voiced, th, noise, loud


def segments(voiced):
    segs, n, i = [], len(voiced), 0
    while i < n:
        if voiced[i]:
            j = i
            while j < n and voiced[j]:
                j += 1
            if j - i >= 6:      # 丢掉 <60ms 的碎片
                segs.append((i * HOP / SR, j * HOP / SR))
            i = j
        else:
            i += 1
    return segs


def write_align(shots):
    out = os.path.join(PROJ, 'src', 'align.json')
    keep = ('no', 't0', 't1', 'subFrom', 'subTo', 'nFrom', 'nTo', 'line', 'text', 'chars')
    json.dump([{k: sh[k] for k in keep} for sh in shots],
              open(out, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    return out


def stub_align(shots):
    """没音频时的占位对齐：按镜头时长均分。
    只用于「先把工程搭起来、类型检查能过」，成片前必须换成真实对齐。"""
    for sh in shots:
        toks = sh['toks']
        n = max(len(toks), 1)
        span = max(sh['t1'] - sh['t0'], 0.6)
        t0 = sh['t0'] + min(0.14, span * 0.05)
        step = span * 0.92 / n
        chars = []
        for i, tk in enumerate(toks):
            ts = t0 + i * step
            for ci, ch in enumerate(tk):
                chars.append(dict(ch=ch, s=round(ts + step * ci / len(tk), 3),
                                  e=round(ts + step * (ci + 1) / len(tk), 3)))
        words = [strip_punct(w) for w in sh['line'].split() if strip_punct(w)]
        acc = 0
        for w in words:
            acc += len(w)
            if acc < len(chars):
                chars[acc - 1]['br'] = 1
        sh['chars'] = chars
        sh['text'] = strip_punct(sh['line'])
        sh['subFrom'] = chars[0]['s'] if chars else sh['t0']
        sh['subTo'] = chars[-1]['e'] if chars else sh['t1']
        sh['nFrom'], sh['nTo'] = sh['t0'], sh['t1']
        sh['grp'] = [0, 0]
        sh['sdur'] = span
    return shots


# ───────────────────────── 主流程 ─────────────────────────
def main():
    dry = '--dry' in sys.argv
    stub = '--stub' in sys.argv
    shots = parse_shots()
    for sh in shots:
        sh['toks'] = tokenize(strip_punct(sh['line']))
        sh['text'] = strip_punct(sh['line'])

    if stub:
        shots = stub_align(shots)
        if dry:
            print('--dry：未写文件')
            return
        out = write_align(shots)
        print(f'已写占位对齐 {out}（按镜头时长均分）。\n'
              f'!! 这只是让工程能编译/预览用的假时间，成片前必须放好口播音频并重跑不带 --stub 的 align.py')
        return
    rms, dur = load_rms()
    sm, voiced, th, noise, loud = vad(rms)
    segs = segments(voiced)

    n, m = len(shots), len(segs)
    N = sum(len(sh['toks']) for sh in shots)
    total_v = sum(b - a for a, b in segs) or 1e-6
    rho = N / total_v
    print(f'audio {dur:.2f}s | voiced {total_v:.2f}s ({total_v/dur*100:.1f}%) | segs {m} | shots {n}')
    print(f'tokens {N} | 语速 {rho:.2f} tok/s | th {th:.0f} noise {noise:.0f} loud {loud:.0f}')

    if m < n:
        print(f'!! 语音段({m}) 少于句子({n})，DP 无解，退化为按字数比例分配。'
              f'大概率是台词字数与真实口播差异过大，或某个镜头台词是空的。')
        assign_fallback(shots, segs, dur)
    else:
        assign_dp(shots, segs, rho)

    # ── 用首字起声反推镜头切点：画面要抢在人声之前 ──
    nf = []
    for i, sh in enumerate(shots):
        v = sh['subFrom'] - LEAD
        if i > 0:
            v = max(v, nf[-1] + MINLEN)
        nf.append(round(max(v, 0.0), 3))
    nf[0] = 0.0
    nt = [round(x, 3) for x in nf[1:]] + [round(dur, 3)]
    for i, sh in enumerate(shots):
        sh['nFrom'], sh['nTo'] = nf[i], nt[i]

    # ── 诊断表：dL/dR 是字幕相对初剪时间码的偏移，超过 0.5s 说明初剪估得太离谱 ──
    print(f"\n{'shot':5} {'初剪窗':>13} {'字幕窗':>13} {'dL':>6} {'dR':>6} {'tok':>4} {'语速':>5} {'段':>3}")
    warn = 0
    for sh in shots:
        dl = sh['subFrom'] - sh['t0']
        dr = sh['subTo'] - sh['t1']
        flag = ''
        if abs(dl) > 0.5 or abs(dr) > 0.5:
            flag = ' <<'
            warn += 1
        dens = len(sh['toks']) / sh['sdur'] if sh['sdur'] > 0 else 0
        print(f"{sh['no']:5} {sh['t0']:6.2f}-{sh['t1']:6.2f} {sh['subFrom']:6.2f}-{sh['subTo']:6.2f} "
              f"{dl:+6.2f} {dr:+6.2f} {len(sh['toks']):4} {dens:5.2f} {sh['grp'][1]-sh['grp'][0]:3}{flag}")
    if warn:
        print(f'\n{warn} 句的初剪时间码与真实语音差 >0.5s（已自动修正，不影响成片；只是提醒你台词可能切错位置）')

    if dry:
        print('\n--dry：未写文件')
        return

    out = write_align(shots)
    print(f'\n-> {out}  ({len(shots)} 句, 末镜结束 {nt[-1]:.2f}s)')


def assign_dp(shots, segs, rho):
    """DP：把 segs 切成 len(shots) 个连续组，让每组语速尽量接近全片语速"""
    n, m = len(shots), len(segs)
    INF = float('inf')
    pref = [0.0]
    for a, b in segs:
        pref.append(pref[-1] + (b - a))

    def cost(g, i, j):
        d = pref[j] - pref[i]
        if d <= 0.05:
            return INF
        dev = (len(shots[g]['toks']) / d - rho) / rho
        pen = 0.0 if abs(dev) < 0.35 else (abs(dev) - 0.35) ** 2 * 40
        return dev ** 2 + pen

    dp = [[INF] * (m + 1) for _ in range(n + 1)]
    bk = [[-1] * (m + 1) for _ in range(n + 1)]
    dp[0][0] = 0
    for g in range(1, n + 1):
        for j in range(1, m + 1):
            for i in range(g - 1, j):
                if dp[g - 1][i] == INF:
                    continue
                c = dp[g - 1][i] + cost(g - 1, i, j)
                if c < dp[g][j]:
                    dp[g][j], bk[g][j] = c, i
    if dp[n][m] == INF:
        print('!! DP 无解，退化为比例分配')
        return assign_fallback(shots, segs, segs[-1][1])
    print(f'DP 最优代价 {dp[n][m]:.3f}')

    bounds = [0] * (n + 1)
    j = m
    for g in range(n, 0, -1):
        bounds[g - 1] = bk[g][j]
        j = bk[g][j]
    bounds[n] = m

    for g, sh in enumerate(shots):
        fill_group(sh, segs[bounds[g]:bounds[g + 1]])


def assign_fallback(shots, segs, dur):
    """段数不够时：按字数比例在整条音轨上均分（比按镜头时长均分准一些）"""
    total = sum(len(sh['toks']) for sh in shots) or 1
    t = segs[0][0] if segs else 0.0
    span = (segs[-1][1] if segs else dur) - t
    for sh in shots:
        share = len(sh['toks']) / total
        a, b = t, t + span * share
        sub = [(a, b)]
        t = b
        sh['grp'] = [0, 1]
        fill_group(sh, sub)


def fill_group(sh, sub):
    """组内按各段容量把 token 顺序消费掉"""
    toks = sh['toks']
    d = sum(b - a for a, b in sub)
    sh['sdur'] = round(d, 2)
    ntok = len(toks)
    if not sub or d <= 0:
        # 没有语音：整句压在该镜起点后 0.2s 内（保证能渲染）
        base = sh['t0'] + 0.2
        sh['chars'] = [dict(ch=ch, s=round(base + i * 0.12, 3), e=round(base + (i + 1) * 0.12, 3))
                       for i, ch in enumerate(toks)]
        sh['subFrom'], sh['subTo'] = sh['chars'][0]['s'], sh['chars'][-1]['e']
        sh['grp'] = [0, 0]
        return

    dens = ntok / d
    # 每段能装多少 token（按段时长容量分配，余数补给偏差最大的段）
    raw = [dens * (b - a) for a, b in sub]
    cap = [int(c) for c in raw]
    rem = ntok - sum(cap)
    order = sorted(range(len(raw)), key=lambda i: raw[i] - cap[i], reverse=True)
    k = 0
    while rem > 0:
        cap[order[k % len(order)]] += 1
        rem -= 1
        k += 1
    while rem < 0:
        if cap[order[k % len(order)]] > 0:
            cap[order[k % len(order)]] -= 1
            rem += 1
        k += 1

    chars, si, used = [], 0, 0
    for tk in toks:
        while si < len(sub) and used >= max(cap[si], 1):
            si += 1
            used = 0
        if si >= len(sub):
            si = len(sub) - 1
        a, b = sub[si]
        kk = max(cap[si], 1)
        ts = a + (b - a) * (used / kk)
        te = a + (b - a) * ((used + 1) / kk)
        used += 1
        L = len(tk)
        for ci, ch in enumerate(tk):
            chars.append(dict(ch=ch,
                              s=round(ts + (te - ts) * ci / L, 3),
                              e=round(te - (te - ts) * (L - 1 - ci) / L, 3)))

    # 词尾打 br 标记 → 字幕优先在词边界折行
    words = [strip_punct(w) for w in sh['line'].split() if strip_punct(w)]
    acc = 0
    for w in words:
        acc += len(w)
        if acc < len(chars):
            chars[acc - 1]['br'] = 1

    sh['chars'] = chars
    sh['grp'] = [0, len(sub)]
    sh['subFrom'] = chars[0]['s'] if chars else sh['t0']
    sh['subTo'] = chars[-1]['e'] if chars else sh['t1']


if __name__ == '__main__':
    main()

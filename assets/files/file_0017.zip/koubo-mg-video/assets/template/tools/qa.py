# -*- coding: utf-8 -*-
"""
静帧质检 —— 渲染若干帧、拼成宫格、并自动标出"看起来有问题"的帧。

为什么需要它：
  逐镜头渲染静帧人眼过一遍，是发现穿帮最快的方式（元素错位、文字溢出、
  漏铺背景透出全屏人物、整帧空白）。但全片几十帧纯靠眼看会漏，
  所以这里先用图像统计筛一遍：亮度极低 / 对比度极低 / 边缘极少 的帧会被点名。

用法：
  python tools/qa.py --times 3,8,15,26,44      # 指定秒数
  python tools/qa.py --every 6                 # 每 6 秒一帧
  python tools/qa.py --times 3,8 --no-render    # 只分析已渲染的帧

输出： out/qa/f<帧号>.png + out/qa/grid.jpg + 终端报告
"""
import glob
import os
import subprocess
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(PROJ)
QA = os.path.join(PROJ, 'out', 'qa')
COMP = 'Video'


def sh(cmd):
    return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True,
                          encoding='utf-8', errors='replace')


def render(frame: int):
    out = os.path.join(QA, f'f{frame:05d}.png')
    if os.path.exists(out):
        return out
    bin_ = os.path.join('node_modules', '.bin', 'remotion')
    pub = os.path.join(PROJ, 'public').replace('\\', '/')
    cmd = f'"{bin_}" still src/index.ts {COMP} "{out}" --frame={frame} --public-dir="{pub}" --log=error'
    r = sh(['bash', '-c', cmd])
    if not os.path.exists(out):
        print(f'  渲染失败 frame={frame}: {(r.stderr or r.stdout or "")[-300:]}')
        return None
    return out


def analyze(path):
    """返回 (平均亮度, 对比度std, 边缘密度) —— 用来粗筛空白/过暗/过平"""
    from PIL import Image, ImageFilter
    im = Image.open(path).convert('L').resize((270, 480))
    px = list(im.getdata())
    n = len(px)
    mean = sum(px) / n
    var = sum((p - mean) ** 2 for p in px) / n
    edges = im.filter(ImageFilter.FIND_EDGES)
    ep = list(edges.getdata())
    emean = sum(ep) / len(ep)
    return mean, var ** 0.5, emean


def grid(paths, out):
    """拼 6 列宫格"""
    from PIL import Image
    cols = 6
    rows = (len(paths) + cols - 1) // cols
    tw, th = 200, 356
    canvas = Image.new('RGB', (tw * cols, th * rows), (245, 245, 245))
    for i, p in enumerate(paths):
        im = Image.open(p).convert('RGB').resize((tw, th))
        canvas.paste(im, ((i % cols) * tw, (i // cols) * th))
    canvas.save(out, quality=82)
    return out


def main():
    os.makedirs(QA, exist_ok=True)
    no_render = '--no-render' in sys.argv
    frames = []

    if '--every' in sys.argv:
        step = float(sys.argv[sys.argv.index('--every') + 1])
        # 从 timeline.ts 的 TOTAL 拿不到，就按每条时长估：直接读 align.json 末镜
        try:
            import json
            al = json.load(open('src/align.json', encoding='utf-8'))
            dur = al[-1]['nTo']
        except Exception:
            dur = 60.0
        t = step
        while t < dur:
            frames.append(round(t * 30))
            t += step
    elif '--times' in sys.argv:
        raw = sys.argv[sys.argv.index('--times') + 1]
        frames = [round(float(x) * 30) for x in raw.split(',') if x.strip()]
    else:
        print(__doc__)
        return

    if not no_render:
        print(f'渲染 {len(frames)} 帧 ...')
        for f in frames:
            render(f)

    got = sorted(glob.glob(os.path.join(QA, 'f*.png')))
    if not got:
        sys.exit('out/qa 里没有帧可分析')

    print(f'\n{"帧":>6} {"秒":>7} {"亮度":>6} {"对比":>6} {"边缘":>6}  判定')
    flagged = []
    for p in got:
        fr = int(os.path.basename(p)[1:6])
        mean, std, edge = analyze(p)
        flag = ''
        if mean < 26:
            flag = '过暗（可能是空白/黑帧）'
        elif std < 12:
            flag = '过平（几乎纯色，画面是空的？）'
        elif edge < 3.2:
            flag = '边缘极少（元素都被推出画外？）'
        if flag:
            flagged.append((fr, flag))
        print(f'{fr:6} {fr/30:7.1f} {mean:6.1f} {std:6.1f} {edge:6.1f}  {flag}')

    g = grid(got, os.path.join(QA, 'grid.jpg'))
    print(f'\n宫格 -> {os.path.relpath(g, PROJ)}   （{len(got)} 帧）')

    if flagged:
        print('\n需要注意的帧：')
        for fr, f in flagged:
            print(f'  f{fr} ({fr/30:.1f}s) {f}')
    else:
        print('\n自动筛查没发现空白/过暗帧。仍要人眼看宫格：自动筛查发现不了'
              '「元素错位」「文字溢出」「漏铺背景透出全屏人物」这类问题。')


if __name__ == '__main__':
    main()

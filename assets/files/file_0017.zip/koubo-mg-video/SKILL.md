---
name: koubo-mg-video
display_name: 口播MG动画流水线
description: "竖屏真人口播 + MG 动画视频的完整制作流水线（Remotion 代码渲染）。从一句关键词或一段口播底片出发，自动分镜、用能量 VAD 把字幕和动画卡点钉到真实语音上、程序化合成音效、逐镜静帧验收，产出 1080×1920 成片。当用户要做「口播视频加动画」「口播配 MG 动效」「真人口播 + 字卡/图表动画」「把口播稿做成带动效的竖屏视频」，或要求字幕跟着说话走、动画卡在说话的点上、把长口播拆成多镜头配动画时使用。不依赖任何外部素材库或编导台，音效全部程序化合成。"
---

# 口播 MG 动画流水线

一条竖屏口播片从"人对着镜头说话"变成"说话的同时画面在演进"。
核心只有一件事：**画面、字幕、语音三者同拍**。观众说不出为什么，但一旦错拍就会立刻觉得"业余"。

## 这个 skill 的差异化在哪

普通做法是「先定 30 个镜头、每个镜头平均分台词」，结果字幕会整体漂移 0.5–2 秒，
且每句漂移量不同 —— 因为真人说话有停顿、有快慢，不是匀速念稿。

这里的做法是反过来：**先测出人到底在什么时候说了哪个字，再让画面去追语音**。
`tools/align.py` 做的事就是：能量 VAD 找出全部真实语音段 → 动态规划把语音段映射到每句台词
→ 每个字拿到真实发音帧 → 再用首字起声反推镜头切点。

所以这套流程里，"剧本时间码"只是初剪草稿，真正的唯一事实源是 `src/align.json`。

## 安装与自检

把整个 `koubo-mg-video/` 目录放进 `~/.workbuddy/skills/`（用户级，全局可用）
或 `<工程>/.workbuddy/skills/`（项目级），重启会话即可被识别。

依赖只有两样，都是外部环境、不在本目录里：

| 依赖 | 用途 | 检查 |
|---|---|---|
| Node 18+ / npx | Remotion 渲染 | `node -v` |
| Python 3.9+（纯标准库） | 对齐、音效合成、质检 | `python -V` |
| ffmpeg / ffprobe | 抽音轨、抽帧、转码 | `ffmpeg -version` |

自检：`node <SKILL_DIR>/scripts/new_project.mjs /tmp/smoke --video <任意mp4>` 能建出工程、
`cd /tmp/smoke && python tools/gen_sfx.py` 能生成 24 个 wav，就说明环境齐了。

**不需要** 事先准备音效包、字体包、素材库、编导台 —— 音效由 `gen_sfx.py` 用正弦/噪声现场合成，
字体走系统 font-family 回退栈，素材就是用户自己的截图和底片。

## 开工前先判断素材完备度

| 情况 | 缺什么 | 怎么走 |
|---|---|---|
| 有口播底片（人或录音） | 只缺文案 | 从 `probe.py` 开始，文案由你按语音内容写，逐句切镜头 |
| 有文案 + 关键词，没底片 | 缺语音 | 先用 TTS 生成配音（问用户要音色），拿到音频再走同一条流水线 |
| 只给一个关键词 | 什么都缺 | 先调研 → 写 12 拍文案 → 定镜头 → 录/合成配音 → 再进流水线 |

**底片是硬前提**。没有真人底片时，人像窗口退化成"人物图 + 轻微动效"，但同样要保证不穿帮。

## 五阶段

### 阶段 1 · 体检与配置（10 分钟）

```bash
# 在任意目录执行；<SKILL_DIR> = 本 skill 所在目录（不是工程目录）
node <SKILL_DIR>/scripts/new_project.mjs <工程目录> --video "<口播.mp4>" --node-modules "<旧工程>/node_modules"
cd <工程目录>
python tools/probe.py
```

`probe.py` 会打印分辨率/时长/编码，并抽 3 帧到 `analysis/face_check_*.jpg`。
**必须打开中间那帧，量出脸的像素中心坐标，填进 `src/project.ts` 的 `face`** ——
它决定圆形气泡和竖版面板把底片裁到哪里，填错就是"气泡里只有半张脸"。

同一个文件里还要填 `brand` / `tagline` / `logo` / `theme`（paper / ink / night 三套预设）。

### 阶段 2 · 分镜（把文案变成镜头表）

编辑 `src/shots.ts` 的 `SHOTS_DEF`。规则：

- 一镜 ≈ 一句完整的话（3–6 秒）。超过 7 秒要拆，观众会走神
- 台词里**词与词之间用空格分隔** —— 这是逐词卡点的唯一依据
- 台词不写标点；需要断句就多切一镜
- 镜头类型三选一：
  - `LIVE` 全屏真人口播（说观点、转折、金句时用，全片占 30–40%）
  - `MG` 纯动画（讲概念、列结构、做对比时用，占 40–50%）
  - `ASSET` 真实截图/录屏当主视觉（证明"我真的用过"，占 15–25%）

**黄金比例**：连续 2 个 MG 之后必须回到 LIVE 或 ASSET，否则观众会觉得"人不见了"。
每 8–10 秒要有一次呼吸（一个 LIVE 或一个空镜），全程高能不现实。

同时配 `WINDOWS`（哪几镜出现人像窗、在第几位）、`SFX_DEF`（音效钉帧）、`ACT_STATIONS`（顶部进度条三站）。

### 阶段 3 · 实现镜头（工作量最大的部分）

在 `src/scenes/` 下按幕分文件写 React 组件，再注册到 `src/scenes/index.ts`。
`src/scenes/starter.tsx` 给了三种类型的标准写法，照抄结构改内容即可。

**每个场景必须遵守的四条**（违反任何一条都会出穿帮）：

1. **MG / ASSET 场景第一层必须是 `<StudioBG />`**。漏铺 → 透出底层全屏真人，
   和右下气泡里的人物"双人同屏"。这是最容易犯、也最致命的错误。
2. **动画只用镜头本地帧**。Root 用 `<Sequence>` 包了场景，`useCurrentFrame()` 拿到的就是本地帧，
   但 `wordTimes()/SUBS` 给的是全片帧，取用时必须减掉 `shotByNo(no).from`（用 `scenes/util.ts` 的封装）。
3. **逐词卡点统一走 `wordFramesLocal(no)`**，不要手写 `[24, 40, 56, 70]` 这种魔数。
4. **LIVE 场景是透明 overlay**，只叠花字/贴纸，不能铺任何底。

素材图右侧常有空白区 —— 那不是留白，是**要填动态内容的地方**（见 `references/layout-grammar.md`）。

### 阶段 4 · 对齐与声音

```bash
python tools/align.py          # 真实语音对齐，覆盖 align.json
npx tsc --noEmit
```

`align.py` 会打一张诊断表：每句的 `dL/dR`（字幕相对初剪时间码的偏移）、语速、分到几个语音段。
- 各句语速应该接近（偏差 <20%）。某句明显偏高 → 台词字数与实际说的不符，改台词
- `dL/dR` 超过 0.5s 的句子会标 `<<`。少量正常（初剪粗估），但如果连续多句都偏 → 台词切错位置了

音效已经由 `tools/gen_sfx.py` 合成好（24 种 + 1 条 BGM 循环），不需要任何外部音频。
需要新音色就跑 `python tools/gen_sfx.py <名字>`，或在 `gen_sfx.py` 里加配方。
音量在 `shots.ts` 的 `vol` 字段控制，**0.08–0.20，永远不能盖住口播**。

### 阶段 5 · 验收与出片

```bash
python tools/qa.py --every 5        # 渲染静帧 + 自动筛空白/过暗 + 拼宫格
npx remotion render src/index.ts Video out/video.mp4 --public-dir="$(pwd)/public"
npx remotion render src/index.ts VideoNoBgm out/video-nobgm.mp4 --public-dir="$(pwd)/public"
```

`qa.py` 的自动筛查只能发现"整帧空白 / 过暗 / 元素被推出画外"，
**发现不了"元素错位""文字溢出""漏铺背景"** —— 宫格图必须人眼过一遍。
逐条对照 `references/qa-checklist.md`。

两版都要出：带 BGM 版给用户直接用，无 BGM 版方便他自己配乐。
渲染完成后**必须 `ls -la` 核对文件时间戳**，确认这次真的写成功了（曾出现 render 静默失败、读到旧文件的情况）。

## 铁律（都是踩过的坑，别再踩）

| 铁律 | 违反的后果 |
|---|---|
| MG/ASSET 必须铺不透明背景 | 双人物同屏，全片最致命的穿帮 |
| MG 背景的淡入必须为 0 帧（硬切） | 淡入的 8 帧会透出全屏真人 |
| 人像窗只在镜头开头 12 帧内移动完 | 连续漂移会让观众晕，且显得廉价 |
| 字幕出现气泡的镜头，字幕带要给气泡让位 | 长句压到人脸上 |
| 特效音效 vol ≤ 0.20 | 抢口播，是"业余感"的第二大来源 |
| 逐词卡点从 `wordFramesLocal` 取 | 手写魔数必然与语音脱拍 |
| 场景组件必须被 `<Sequence>` 包住 | 所有动画用绝对帧，时序全乱 |
| `public-dir` 必须传绝对路径 | 中文路径/目录联接会让 Remotion 拿不到素材（404） |
| 台词词间必须留空格 | 逐词卡点全部失效，石板一起落 |

## 目录结构

```
<工程>/
├── src/
│   ├── project.ts        ← 只改这里：品牌、素材名、人脸坐标、主题
│   ├── shots.ts          ← 只改这里：镜头表、人像窗、SFX 钉帧
│   ├── theme.ts          三套调色板 + 字体 + 缓动曲线
│   ├── timeline.ts       派生层（不要手改）：SHOTS/SUBS/wordTimes/SFX
│   ├── align.json        对齐结果（align.py 生成）
│   ├── Root.tsx          主合成：底片→场景→人像窗→品牌栏→字幕→声音
│   ├── components/
│   │   ├── kit.tsx       版式件：StudioBG/GhostTitle/WhiteCard/Stamp/Pill/Ring...
│   │   ├── fx.tsx        强调件：CircleMark/Underline/ArrowCue/BurstTag/Sweep/Floaters...
│   │   ├── moves.tsx     招牌动效：IrisCut/FlipList/StairTrace/RisoSlam/Spotlight/ThemeSweep/Particles
│   │   ├── PersonWindow.tsx  人像气泡/面板
│   │   └── KaraokeSub.tsx    逐字高亮字幕
│   └── scenes/           镜头实现 + util.ts（本地帧换算）
├── tools/
│   ├── probe.py          素材体检 + 抽帧
│   ├── align.py          VAD + DP 真实语音对齐
│   ├── gen_sfx.py        程序化音效合成（纯标准库）
│   └── qa.py             静帧质检 + 自动筛空白 + 宫格
└── public/
    ├── voice.mp4         口播底片
    ├── textures/         你自己的截图、录屏、logo 放这里
    ├── audio/voice.m4a   口播音轨
    └── audio/sfx/*.wav   合成音效
```

**不需要编导台、不需要脚本表格、不需要任何外部素材库**：
镜头表是 `shots.ts` 里的一段文字，文案按 `references/script-and-shots.md` 的 12 拍法自己写，
时间轴由 `align.py` 从语音里测出来。一条命令能起一个空工程，剩下全靠写代码。

## 参考文档

- `references/pipeline.md` — 五阶段的详细操作与检查点、分镜方法
- `references/script-and-shots.md` — 从关键词/口播内容自动写文案与镜头表（不需要任何编导台）
- `references/layout-grammar.md` — 竖屏版式语法：安全区、字号阶梯、卡片、素材空白区填法
- `references/subtitle-align.md` — 对齐算法原理、调参与排错
- `references/motion-library.md` — 动效元件清单、7 个招牌转场写法、语义映射表
- `references/sound-design.md` — 音效钉帧逻辑、音量规范、合成配方
- `references/qa-checklist.md` — 出片前逐条验收清单
